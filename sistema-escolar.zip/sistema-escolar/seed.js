﻿require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const User = require('./models/User');
const Task = require('./models/Task');
const Notice = require('./models/Notice');
const Schedule = require('./models/Schedule');
const Grade = require('./models/Grade');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/sistema_escolar';

// Lista de alumnos realistas
const alumnosData = [
  { matricula: '20260001', nombre: 'Mario Alumno Pérez', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260002', nombre: 'Valeria Gómez Sánchez', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260003', nombre: 'Carlos Eduardo Ramírez', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260004', nombre: 'Ana Sofía Martínez Ruiz', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260005', nombre: 'Luis Fernando Torres Cruz', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260006', nombre: 'Daniela Morales Reyes', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260007', nombre: 'Javier Alejandro Vargas', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260008', nombre: 'Paola Fernanda López Díaz', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260009', nombre: 'Rodrigo Castillo Medina', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260010', nombre: 'Camila Navarro Herrera', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260011', nombre: 'Emiliano Ortiz Domínguez', password: 'upa2026', rol: 'Alumno' },
  { matricula: '20260012', nombre: 'Andrea Jimena Castro Gil', password: 'upa2026', rol: 'Alumno' }
];

// Horarios y materias académicas
const schedulesData = [
  { materia: 'Bases de Datos NoSQL', profesor: 'Ing. Profe', horario: 'Lun - Mié 08:00 - 10:00', aula: 'Lab Ciberseguridad' },
  { materia: 'Desarrollo Web Full Stack', profesor: 'Mtra. Elena Salgado', horario: 'Mar - Jue 10:00 - 12:00', aula: 'Lab Software 2' },
  { materia: 'Seguridad en Redes', profesor: 'Ing. Profe', horario: 'Vie 08:00 - 12:00', aula: 'Lab Redes y Telecom' },
  { materia: 'Inteligencia Artificial', profesor: 'Dr. Roberto Mendoza', horario: 'Lun - Mié 12:00 - 14:00', aula: 'Edificio 3, Aula 12' },
  { materia: 'Arquitectura de Software', profesor: 'Mtro. Héctor Palacios', horario: 'Mar - Jue 08:00 - 10:00', aula: 'Edificio 2, Aula 8' },
  { materia: 'Computación en la Nube', profesor: 'Mtra. Elena Salgado', horario: 'Vie 12:00 - 15:00', aula: 'Lab Cómputo Nube' },
  { materia: 'Metodologías Ágiles', profesor: 'Mtro. Héctor Palacios', horario: 'Jue 14:00 - 16:00', aula: 'Edificio 1, Aula 5' }
];

// Tareas escolares variadas
const tasksData = [
  { titulo: 'Práctica 1: Modelado de Documentos en MongoDB', materia: 'Bases de Datos NoSQL', descripcion: 'Diseñar esquemas con Mongoose e implementar índices.', fechaEntrega: '2026-11-28', estatus: 'Entregado' },
  { titulo: 'API REST con Express 5 y Sesiones', materia: 'Desarrollo Web Full Stack', descripcion: 'Implementar rutas protegidas con express-session y bcrypt.', fechaEntrega: '2026-12-02', estatus: 'Pendiente' },
  { titulo: 'Análisis de Tráfico con Wireshark', materia: 'Seguridad en Redes', descripcion: 'Capturar y filtrar paquetes en protocolo TCP y UDP.', fechaEntrega: '2026-12-04', estatus: 'Entregado' },
  { titulo: 'Entrenamiento de Red Neuronal Básica', materia: 'Inteligencia Artificial', descripcion: 'Implementar clasificador de imágenes con TensorFlow.', fechaEntrega: '2026-12-06', estatus: 'Pendiente' },
  { titulo: 'Diagrama C4 de Arquitectura de Microservicios', materia: 'Arquitectura de Software', descripcion: 'Entregar modelo de contexto, contenedores y componentes.', fechaEntrega: '2026-12-08', estatus: 'Pendiente' },
  { titulo: 'Despliegue de Contenedores en Docker y AWS', materia: 'Computación en la Nube', descripcion: 'Configurar Dockerfile, compose y subir instancia a la nube.', fechaEntrega: '2026-12-10', estatus: 'Pendiente' },
  { titulo: 'Sprint Planning y Tablero Kanban en Jira', materia: 'Metodologías Ágiles', descripcion: 'Crear user stories con criterios de aceptación e historias de usuario.', fechaEntrega: '2026-12-12', estatus: 'Entregado' },
  { titulo: 'Benchmark de Índices Compuestos vs Simples', materia: 'Bases de Datos NoSQL', descripcion: 'Generar reporte comparativo con explain executionStats.', fechaEntrega: '2026-12-15', estatus: 'Pendiente' },
  { titulo: 'Auditoría OWASP Top 10 en Aplicación Web', materia: 'Seguridad en Redes', descripcion: 'Pruebas de inyección NoSQL, XSS y fijación de sesiones.', fechaEntrega: '2026-12-18', estatus: 'Pendiente' }
];

// Avisos escolares
const noticesData = [
  { titulo: 'Período de Evaluaciones Parciales y Cierre de Actas', autor: 'Coordinación Académica', mensaje: 'Se les recuerda a todos los docentes que el registro de calificaciones del Parcial 2 concluye el próximo viernes.', prioridad: 'Urgente', fecha: new Date(Date.now() - 3600000 * 2) },
  { titulo: 'Mantenimiento en Laboratorio de Ciberseguridad', autor: 'Soporte Técnico', mensaje: 'El laboratorio 3 estará en actualización de equipos y cableado de red durante el sábado de 08:00 a 14:00 hrs.', prioridad: 'Importante', fecha: new Date(Date.now() - 3600000 * 24) },
  { titulo: 'Convocatoria Hackathon Universitario 2026', autor: 'Sociedad de Alumnos', mensaje: 'Inscripciones abiertas para el hackathon de desarrollo web y ciencia de datos. Premios para los primeros 3 lugares.', prioridad: 'Normal', fecha: new Date(Date.now() - 3600000 * 48) },
  { titulo: 'Entrega de Becas y Validación de Promedios', autor: 'Servicios Escolares', mensaje: 'Los alumnos con promedio superior a 90 pueden consultar la lista de beneficiarios en la ventanilla de servicios escolares.', prioridad: 'Importante', fecha: new Date(Date.now() - 3600000 * 72) },
  { titulo: 'Talleres Extracurriculares de Python y Docker', autor: 'Ing. Profe', mensaje: 'Inicio del taller sabatino de preparación para certificaciones de nube y desarrollo backend.', prioridad: 'Normal', fecha: new Date(Date.now() - 3600000 * 96) }
];

// Calificaciones variadas para los alumnos
const materiasCalificables = [
  'Bases de Datos NoSQL',
  'Desarrollo Web Full Stack',
  'Seguridad en Redes',
  'Inteligencia Artificial',
  'Arquitectura de Software'
];

async function seedDatabase() {
  try {
    console.log('====================================================');
    console.log('    POBLANDO BASE DE DATOS ESCOLAR (SEED SCRIPT)    ');
    console.log('====================================================\n');

    await mongoose.connect(MONGODB_URI);
    console.log('✔ Conectado a MongoDB:', MONGODB_URI);

    // 1. POBLAR ALUMNOS
    console.log('\n--- 1. Registrando Alumnos ---');
    for (const a of alumnosData) {
      let u = await User.findOne({ matricula: a.matricula });
      if (!u) {
        await User.create(a);
        console.log(`  + Alumno registrado: ${a.matricula} - ${a.nombre}`);
      } else {
        u.nombre = a.nombre;
        u.password = a.password;
        await u.save();
        console.log(`  * Alumno actualizado: ${a.matricula} - ${a.nombre}`);
      }
    }

    // 2. POBLAR HORARIOS
    console.log('\n--- 2. Registrando Horarios y Materias ---');
    await Schedule.deleteMany({});
    await Schedule.insertMany(schedulesData);
    console.log(`✔ ${schedulesData.length} materias registradas en el horario.`);

    // 3. POBLAR TAREAS
    console.log('\n--- 3. Registrando Actividades y Tareas ---');
    await Task.deleteMany({});
    await Task.insertMany(tasksData);
    console.log(`✔ ${tasksData.length} tareas registradas con diversas fechas y estatus.`);

    // 4. POBLAR AVISOS
    console.log('\n--- 4. Registrando Avisos Escolares ---');
    await Notice.deleteMany({});
    await Notice.insertMany(noticesData);
    console.log(`✔ ${noticesData.length} avisos publicados en el tablero.`);

    // 5. POBLAR CALIFICACIONES (Simulación realista)
    console.log('\n--- 5. Generando Calificaciones de Alumnos ---');
    await Grade.deleteMany({});
    const gradesList = [];

    // Matriz de calificaciones con variedad (algunos 90-100, otros 70-85 y un par reprobados para la gráfica)
    alumnosData.forEach((alumno, idx) => {
      materiasCalificables.forEach((materia, mIdx) => {
        // Generar calificación coherente
        let notaBase = 75 + ((idx * 7 + mIdx * 11) % 24);
        if (idx === 4 && mIdx === 2) notaBase = 62; // Caso de reprobado para mostrar contraste
        if (idx === 8 && mIdx === 0) notaBase = 58; // Caso de reprobado
        if (idx === 0) notaBase = 92 + (mIdx % 7); // Alumno Mario con promedio alto

        gradesList.push({
          alumnoMatricula: alumno.matricula,
          materia: materia,
          parcial: mIdx % 2 === 0 ? 'Parcial 1' : 'Parcial 2',
          calificacion: Math.min(100, Math.max(50, notaBase))
        });
      });
    });

    await Grade.insertMany(gradesList);
    console.log(`✔ ${gradesList.length} calificaciones registradas entre todos los alumnos.`);

    console.log('\n====================================================');
    console.log('       ¡BASE DE DATOS POBLADA EXITOSAMENTE!         ');
    console.log('====================================================');
    console.log('\nCUENTAS PARA PROBAR EN http://localhost:3002:');
    console.log('----------------------------------------------------');
    console.log('👑 PROFESOR:');
    console.log('   Matrícula: 20269999 | Contraseña: prof2026');
    console.log('\n🎓 ALUMNOS EJEMPLO (Todos con contraseña: upa2026):');
    console.log('   Matrícula: 20260001 -> Mario Alumno Pérez');
    console.log('   Matrícula: 20260002 -> Valeria Gómez Sánchez');
    console.log('   Matrícula: 20260003 -> Carlos Eduardo Ramírez');
    console.log('   Matrícula: 20260004 -> Ana Sofía Martínez Ruiz');
    console.log('   Matrícula: 20260005 -> Luis Fernando Torres Cruz');
    console.log('   Matrícula: 20260006 -> Daniela Morales Reyes');
    console.log('   (y 6 alumnos más hasta la matrícula 20260012)');
    console.log('----------------------------------------------------\n');

  } catch (err) {
    console.error('Error al poblar la base de datos:', err);
  } finally {
    await mongoose.disconnect();
    console.log('✔ Conexión cerrada.');
  }
}

seedDatabase();
