﻿require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const mongoSanitize = require('express-mongo-sanitize');
const bcrypt = require('bcryptjs');

const Task = require('./models/Task');
const Notice = require('./models/Notice');
const Schedule = require('./models/Schedule');
const User = require('./models/User');
const Grade = require('./models/Grade');

const app = express();
const PORT = process.env.PORT || 3002;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/sistema_escolar';
const SESSION_SECRET = process.env.SESSION_SECRET || 'upa_secreto_escolar_2026_default';

// Configuración de Mongoose para sanitizar filtros automáticamente
mongoose.set('sanitizeFilter', true);

// Conexión a MongoDB
mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log('Conectado a MongoDB (sistema_escolar)');
    
    // Inicializar o sincronizar cuentas de prueba con contraseñas encriptadas con bcrypt
    const alumnoDemo = await User.findOne({ matricula: '20260001' });
    if (!alumnoDemo) {
      await User.create({ matricula: '20260001', nombre: 'Mario Alumno', password: 'upa2026', rol: 'Alumno' });
    } else if (!(await alumnoDemo.compararPassword('upa2026'))) {
      alumnoDemo.password = 'upa2026';
      await alumnoDemo.save();
    }

    const profeDemo = await User.findOne({ matricula: '20269999' });
    if (!profeDemo) {
      await User.create({ matricula: '20269999', nombre: 'Ing. Profe', password: 'prof2026', rol: 'Profesor' });
    } else if (!(await profeDemo.compararPassword('prof2026'))) {
      profeDemo.password = 'prof2026';
      await profeDemo.save();
    }

    console.log('Cuentas listas -> Alumno: 20260001 (pass: upa2026) | Profesor: 20269999 (pass: prof2026)');
  })
  .catch(err => console.error('Error al conectar a MongoDB:', err));

// Middlewares
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Sanitización de parámetros contra Inyección NoSQL (compatible con Express 5)
app.use((req, res, next) => {
  if (req.body) mongoSanitize.sanitize(req.body);
  if (req.params) mongoSanitize.sanitize(req.params);
  if (req.query) mongoSanitize.sanitize(req.query);
  next();
});

app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}));
app.set('view engine', 'ejs');

// Middleware para proteger rutas y pasar datos del usuario autenticado a las vistas
function verificarSesion(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  res.locals.user = req.session.user;
  next();
}

// Función auxiliar para escapar expresiones regulares en búsquedas (previene ReDoS)
function escapeRegex(text) {
  return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
}

// ==========================================
// --- REGISTRO DE USUARIOS ---
// ==========================================
app.get('/registro', (req, res) => {
  res.render('registro', { error: null });
});

app.post('/registro', async (req, res) => {
  try {
    const matricula = String(req.body.matricula || '').trim();
    const nombre = String(req.body.nombre || '').trim();
    const password = String(req.body.password || '');
    // SEGURIDAD: Forzar siempre rol 'Alumno' en el registro público
    const rol = 'Alumno';

    await User.create({ matricula, nombre, password, rol });
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    let mensajeError = 'Error al registrar usuario.';
    if (err.errors && err.errors.password) {
      mensajeError = err.errors.password.message;
    } else if (err.code === 11000) {
      mensajeError = 'Esa matrícula ya está registrada.';
    }
    res.render('registro', { error: mensajeError });
  }
});

// ==========================================
// --- LOGIN Y LOGOUT ---
// ==========================================
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  try {
    const matricula = String(req.body.matricula || '').trim();
    const password = String(req.body.password || '');
    
    // Buscar usuario por matrícula
    const user = await User.findOne({ matricula });

    // Validar contraseña con bcrypt
    if (!user || !(await user.compararPassword(password))) {
      return res.render('login', { error: 'Matrícula o contraseña incorrecta.' });
    }

    req.session.user = {
      id: user._id,
      matricula: user.matricula,
      nombre: user.nombre,
      rol: user.rol
    };

    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.render('login', { error: 'Error en el servidor.' });
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// ==========================================
// --- DASHBOARD ---
// ==========================================
app.get('/dashboard', verificarSesion, async (req, res) => {
  try {
    const user = req.session.user;

    // Métricas generales
    const totalTareas = await Task.countDocuments();
    const totalAvisos = await Notice.countDocuments();
    const totalHorarios = await Schedule.countDocuments();

    let promedio = '0.0';
    let barLabels = [];
    let barValues = [];
    let doughnutLabels = [];
    let doughnutValues = [];

    if (user.rol === 'Profesor') {
      // 1. Pipeline de Agregación MongoDB: Promedio agrupado por materia
      const aggMaterias = await Grade.aggregate([
        {
          $group: {
            _id: '$materia',
            promedio: { $avg: '$calificacion' }
          }
        },
        { $sort: { _id: 1 } }
      ]);

      barLabels = aggMaterias.map(item => item._id);
      barValues = aggMaterias.map(item => Number(item.promedio.toFixed(1)));

      // 2. Pipeline de Agregación MongoDB: Conteo de Aprobados vs Reprobados (≥ 70)
      const aggAprobacion = await Grade.aggregate([
        {
          $group: {
            _id: {
              $cond: [{ $gte: ['$calificacion', 70] }, 'Aprobados (≥ 70)', 'Reprobados (< 70)']
            },
            cantidad: { $sum: 1 }
          }
        }
      ]);

      doughnutLabels = aggAprobacion.map(item => item._id);
      doughnutValues = aggAprobacion.map(item => item.cantidad);

      // Promedio global
      const aggGlobal = await Grade.aggregate([
        { $group: { _id: null, promedioGeneral: { $avg: '$calificacion' } } }
      ]);
      if (aggGlobal.length > 0 && aggGlobal[0].promedioGeneral) {
        promedio = aggGlobal[0].promedioGeneral.toFixed(1);
      }

    } else {
      // Vista Alumno
      const misNotas = await Grade.find({ alumnoMatricula: user.matricula });
      if (misNotas.length > 0) {
        const suma = misNotas.reduce((acc, curr) => acc + curr.calificacion, 0);
        promedio = (suma / misNotas.length).toFixed(1);
      }

      barLabels = misNotas.map(n => n.materia + ` (${n.parcial})`);
      barValues = misNotas.map(n => n.calificacion);

      // Estado de actividades
      const entregadas = await Task.countDocuments({ estatus: 'Entregado' });
      const pendientes = await Task.countDocuments({ estatus: 'Pendiente' });
      doughnutLabels = ['Entregadas', 'Pendientes'];
      doughnutValues = [entregadas, pendientes];
    }

    res.render('dashboard', {
      kpis: {
        promedio,
        totalTareas,
        totalAvisos,
        totalHorarios
      },
      chartData: {
        barLabels,
        barValues,
        doughnutLabels,
        doughnutValues
      }
    });

  } catch (err) {
    console.error(err);
    res.send('Error al generar el panel analítico');
  }
});

// ==========================================
// --- PERFIL DE USUARIO Y CAMBIO DE PASSWORD ---
// ==========================================
app.get('/perfil', verificarSesion, (req, res) => {
  res.render('perfil', {
    error: req.query.error || null,
    success: req.query.success || null
  });
});

app.post('/perfil/cambiar-password', verificarSesion, async (req, res) => {
  try {
    const { passwordActual, nuevaPassword, confirmarPassword } = req.body;
    const user = await User.findOne({ matricula: req.session.user.matricula });

    if (!user) {
      return res.redirect('/login');
    }

    const valida = await user.compararPassword(passwordActual);
    if (!valida) {
      return res.redirect('/perfil?error=' + encodeURIComponent('La contraseña actual es incorrecta.'));
    }

    if (nuevaPassword !== confirmarPassword) {
      return res.redirect('/perfil?error=' + encodeURIComponent('La nueva contraseña y su confirmación no coinciden.'));
    }

    if (nuevaPassword.length < 6) {
      return res.redirect('/perfil?error=' + encodeURIComponent('La nueva contraseña debe tener al menos 6 caracteres.'));
    }

    const passwordsProhibidas = ['123', '123456', 'password', 'abc12345', user.matricula];
    if (passwordsProhibidas.includes(nuevaPassword)) {
      return res.redirect('/perfil?error=' + encodeURIComponent('La contraseña elegida es muy débil o igual a tu matrícula.'));
    }

    user.password = nuevaPassword;
    await user.save();

    res.redirect('/perfil?success=' + encodeURIComponent('Tu contraseña ha sido actualizada correctamente con cifrado seguro.'));
  } catch (err) {
    console.error(err);
    res.redirect('/perfil?error=' + encodeURIComponent('Error al actualizar contraseña: ' + (err.message || 'Error')));
  }
});

// ==========================================
// --- VISTA 1: TAREAS ---
// ==========================================
app.get('/', verificarSesion, async (req, res) => {
  try {
    const { buscar, estatus } = req.query;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = 5;

    let query = {};

    if (buscar) {
      const cleanBuscar = escapeRegex(buscar.trim());
      query.$or = [
        { titulo: { $regex: cleanBuscar, $options: 'i' } },
        { materia: { $regex: cleanBuscar, $options: 'i' } }
      ];
    }

    if (estatus && estatus !== 'Todos') {
      query.estatus = estatus;
    }

    const total = await Task.countDocuments(query);
    const totalPages = Math.ceil(total / limit) || 1;
    const tasks = await Task.find(query)
      .sort({ fechaEntrega: 1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.render('tareas', {
      tasks,
      editTask: null,
      buscar: buscar || '',
      estatusSeleccionado: estatus || 'Todos',
      page,
      totalPages,
      total
    });
  } catch (err) {
    console.error(err);
    res.send('Error al cargar tareas');
  }
});

app.post('/tareas', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { titulo, materia, descripcion, fechaEntrega } = req.body;
    await Task.create({ titulo, materia, descripcion, fechaEntrega });
    res.redirect('/');
  } catch (err) { console.error(err); res.send('Error al crear tarea'); }
});

app.get('/tareas/editar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const editTask = await Task.findById(req.params.id);
    const total = await Task.countDocuments();
    const tasks = await Task.find().sort({ fechaEntrega: 1 }).limit(5);
    res.render('tareas', {
      tasks,
      editTask,
      buscar: '',
      estatusSeleccionado: 'Todos',
      page: 1,
      totalPages: 1,
      total
    });
  } catch (err) { console.error(err); res.send('Error al buscar tarea'); }
});

app.post('/tareas/actualizar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { titulo, materia, descripcion, fechaEntrega, estatus } = req.body;
    await Task.findByIdAndUpdate(req.params.id, { titulo, materia, descripcion, fechaEntrega, estatus });
    res.redirect('/');
  } catch (err) { console.error(err); res.send('Error al actualizar tarea'); }
});

app.post('/tareas/:id/completar', verificarSesion, async (req, res) => {
  try {
    await Task.findByIdAndUpdate(req.params.id, { estatus: 'Entregado' });
    res.redirect('/');
  } catch (err) { console.error(err); res.send('Error'); }
});

app.post('/tareas/:id/eliminar', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    await Task.findByIdAndDelete(req.params.id);
    res.redirect('/');
  } catch (err) { console.error(err); res.send('Error'); }
});

// ==========================================
// --- VISTA 2: AVISO---
// ==========================================
app.get('/avisos', verificarSesion, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = 5;
    const total = await Notice.countDocuments();
    const totalPages = Math.ceil(total / limit) || 1;

    const notices = await Notice.find()
      .sort({ fecha: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.render('avisos', {
      notices,
      editNotice: null,
      page,
      totalPages,
      total
    });
  } catch (err) { console.error(err); res.send('Error al cargar avisos'); }
});

app.post('/avisos', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { titulo, autor, mensaje, prioridad } = req.body;
    await Notice.create({ titulo, autor, mensaje, prioridad });
    res.redirect('/avisos');
  } catch (err) { console.error(err); res.send('Error al crear aviso'); }
});

app.get('/avisos/editar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const editNotice = await Notice.findById(req.params.id);
    const total = await Notice.countDocuments();
    const notices = await Notice.find().sort({ fecha: -1 }).limit(5);
    res.render('avisos', {
      notices,
      editNotice,
      page: 1,
      totalPages: 1,
      total
    });
  } catch (err) { console.error(err); res.send('Error al buscar aviso'); }
});

app.post('/avisos/actualizar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { titulo, autor, mensaje, prioridad } = req.body;
    await Notice.findByIdAndUpdate(req.params.id, { titulo, autor, mensaje, prioridad });
    res.redirect('/avisos');
  } catch (err) { console.error(err); res.send('Error al actualizar aviso'); }
});

app.post('/avisos/:id/eliminar', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    await Notice.findByIdAndDelete(req.params.id);
    res.redirect('/avisos');
  } catch (err) { console.error(err); res.send('Error'); }
});

// ==========================================
// --- VISTA 3: HORARIOS ---
// ==========================================
app.get('/horarios', verificarSesion, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = 6;
    const total = await Schedule.countDocuments();
    const totalPages = Math.ceil(total / limit) || 1;

    const schedules = await Schedule.find()
      .skip((page - 1) * limit)
      .limit(limit);

    res.render('horarios', {
      schedules,
      editSchedule: null,
      page,
      totalPages,
      total
    });
  } catch (err) { console.error(err); res.send('Error al cargar horarios'); }
});

app.post('/horarios', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { materia, profesor, horario, aula } = req.body;
    await Schedule.create({ materia, profesor, horario, aula });
    res.redirect('/horarios');
  } catch (err) { console.error(err); res.send('Error al crear horario'); }
});

app.get('/horarios/editar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const editSchedule = await Schedule.findById(req.params.id);
    const total = await Schedule.countDocuments();
    const schedules = await Schedule.find().limit(6);
    res.render('horarios', {
      schedules,
      editSchedule,
      page: 1,
      totalPages: 1,
      total
    });
  } catch (err) { console.error(err); res.send('Error al buscar horario'); }
});

app.post('/horarios/actualizar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { materia, profesor, horario, aula } = req.body;
    await Schedule.findByIdAndUpdate(req.params.id, { materia, profesor, horario, aula });
    res.redirect('/horarios');
  } catch (err) { console.error(err); res.send('Error al actualizar horario'); }
});

app.post('/horarios/:id/eliminar', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    await Schedule.findByIdAndDelete(req.params.id);
    res.redirect('/horarios');
  } catch (err) { console.error(err); res.send('Error'); }
});

// ==========================================
// --- VISTA 4: CALIFICACIONES ---
// ==========================================
app.get('/calificaciones', verificarSesion, async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = 6;
    let query = {};

    // PRIVACIDAD: Los alumnos solo pueden ver sus propias calificaciones
    if (req.session.user.rol === 'Alumno') {
      query.alumnoMatricula = req.session.user.matricula;
    } else if (req.query.filtroMatricula && req.query.filtroMatricula.trim()) {
      query.alumnoMatricula = req.query.filtroMatricula.trim();
    }

    // Calcular promedio exclusivamente de las calificaciones visibles
    const allMatching = await Grade.find(query);
    let promedio = '0.0';
    if (allMatching.length > 0) {
      const suma = allMatching.reduce((acc, curr) => acc + curr.calificacion, 0);
      promedio = (suma / allMatching.length).toFixed(1);
    }

    const total = allMatching.length;
    const totalPages = Math.ceil(total / limit) || 1;
    const grades = await Grade.find(query)
      .skip((page - 1) * limit)
      .limit(limit);

    res.render('calificaciones', {
      grades,
      promedio,
      editGrade: null,
      filtroMatricula: req.query.filtroMatricula || '',
      page,
      totalPages,
      total
    });
  } catch (err) { console.error(err); res.send('Error al cargar calificaciones'); }
});

app.post('/calificaciones', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { alumnoMatricula, materia, calificacion, parcial } = req.body;

    // Validación de Integridad Referencial: Verificar que el alumno exista
    const alumno = await User.findOne({ matricula: alumnoMatricula.trim() });
    if (!alumno) {
      console.warn(`Intento de registrar calificación para matrícula inexistente: ${alumnoMatricula}`);
    }

    await Grade.create({ alumnoMatricula: alumnoMatricula.trim(), materia, calificacion, parcial });
    res.redirect('/calificaciones');
  } catch (err) { console.error(err); res.send('Error al registrar calificación'); }
});

app.get('/calificaciones/editar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const editGrade = await Grade.findById(req.params.id);
    const allGrades = await Grade.find();
    let promedio = '0.0';
    if (allGrades.length > 0) {
      const suma = allGrades.reduce((acc, curr) => acc + curr.calificacion, 0);
      promedio = (suma / allGrades.length).toFixed(1);
    }
    const grades = await Grade.find().limit(6);
    res.render('calificaciones', {
      grades,
      promedio,
      editGrade,
      filtroMatricula: '',
      page: 1,
      totalPages: 1,
      total: allGrades.length
    });
  } catch (err) { console.error(err); res.send('Error al buscar calificación'); }
});

app.post('/calificaciones/actualizar/:id', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const { alumnoMatricula, materia, calificacion, parcial } = req.body;
    await Grade.findByIdAndUpdate(req.params.id, { alumnoMatricula, materia, calificacion, parcial });
    res.redirect('/calificaciones');
  } catch (err) { console.error(err); res.send('Error al actualizar calificación'); }
});

app.post('/calificaciones/:id/eliminar', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    await Grade.findByIdAndDelete(req.params.id);
    res.redirect('/calificaciones');
  } catch (err) { console.error(err); res.send('Error'); }
});

// ==========================================
// --- BOLETA OFICIAL IMPRIMIBLE / PDF ---
// ==========================================
app.get('/calificaciones/imprimir', verificarSesion, async (req, res) => {
  try {
    const user = req.session.user;
    let matriculaObjetivo = user.matricula;

    // Si es profesor y envió una matrícula específica por query, imprime la de ese alumno
    if (user.rol === 'Profesor' && req.query.matricula) {
      matriculaObjetivo = req.query.matricula.trim();
    }

    const alumno = await User.findOne({ matricula: matriculaObjetivo }) || {
      matricula: matriculaObjetivo,
      nombre: user.nombre
    };

    const grades = await Grade.find({ alumnoMatricula: matriculaObjetivo });
    let promedio = '0.0';
    if (grades.length > 0) {
      const suma = grades.reduce((acc, curr) => acc + curr.calificacion, 0);
      promedio = (suma / grades.length).toFixed(1);
    }

    const fechaEmision = new Date().toLocaleDateString('es-MX', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    res.render('boleta_imprimir', {
      alumno,
      grades,
      promedio,
      fechaEmision
    });

  } catch (err) {
    console.error(err);
    res.send('Error al generar boleta oficial');
  }
});

// ==========================================
// --- EXPORTAR CALIFICACIONES A CSV (EXCEL) ---
// ==========================================
app.get('/calificaciones/exportar-csv', verificarSesion, async (req, res) => {
  if (req.session.user.rol !== 'Profesor') return res.status(403).render('403');
  try {
    const grades = await Grade.find().sort({ alumnoMatricula: 1, materia: 1 });

    // Encabezado CSV con BOM UTF-8 para que Excel en Windows respete acentos
    let csv = '\uFEFFMatrícula,Materia,Parcial,Calificación,Estado\r\n';

    grades.forEach(g => {
      const estado = g.calificacion >= 70 ? 'Aprobado' : 'Reprobado';
      const materiaEscapada = `"${g.materia.replace(/"/g, '""')}"`;
      csv += `${g.alumnoMatricula},${materiaEscapada},${g.parcial},${g.calificacion},${estado}\r\n`;
    });

    const filename = `acta_calificaciones_${new Date().toISOString().slice(0, 10)}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.status(200).send(csv);

  } catch (err) {
    console.error(err);
    res.status(500).send('Error al exportar calificaciones');
  }
});

app.listen(PORT, () => {
  console.log(`Servidor escolar corriendo en http://localhost:${PORT}`);
});

