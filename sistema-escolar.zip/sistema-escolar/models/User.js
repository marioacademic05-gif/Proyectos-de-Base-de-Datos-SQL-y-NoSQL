﻿const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  matricula: { type: String, required: true, unique: true },
  nombre: { type: String, required: true },
  password: { 
    type: String, 
    required: true,
    minlength: [6, 'La contraseña debe tener al menos 6 caracteres.'],
    validate: {
      validator: function(value) {
        if (value.startsWith('$2a$') || value.startsWith('$2b$')) return true;
        const passwordsProhibidas = ['123', '123456', 'password', 'abc12345', this.matricula];
        return !passwordsProhibidas.includes(value);
      },
      message: 'La contraseña es demasiado débil, común o es igual a tu matrícula. Elige otra.'
    }
  },
  rol: { type: String, enum: ['Alumno', 'Profesor'], default: 'Alumno' }
});

userSchema.pre('save', async function() {
  if (this.isModified('password')) {
    if (!this.password.startsWith('$2a$') && !this.password.startsWith('$2b$')) {
      const salt = await bcrypt.genSalt(10);
      this.password = await bcrypt.hash(this.password, salt);
    }
  }
});

userSchema.methods.compararPassword = async function(candidata) {
  if (!this.password) return false;
  if (this.password.startsWith('$2a$') || this.password.startsWith('$2b$')) {
    return await bcrypt.compare(candidata, this.password);
  }
  return candidata === this.password;
};

module.exports = mongoose.model('User', userSchema);
