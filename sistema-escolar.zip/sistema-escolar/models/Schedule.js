const mongoose = require('mongoose');

const scheduleSchema = new mongoose.Schema({
  materia: { type: String, required: true },
  profesor: { type: String, required: true },
  horario: { type: String, required: true }, 
  aula: { type: String, required: true }      
});
module.exports = mongoose.model('Schedule', scheduleSchema);