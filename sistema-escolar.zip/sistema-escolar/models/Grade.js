const mongoose = require('mongoose');

const gradeSchema = new mongoose.Schema({
  alumnoMatricula: { type: String, required: true },
  materia: { type: String, required: true },
  calificacion: { type: Number, required: true, min: 0, max: 100 },
  parcial: { type: String, default: 'Parcial 1' }
});

module.exports = mongoose.model('Grade', gradeSchema);
