const mongoose = require('mongoose');

const noticeSchema = new mongoose.Schema({
  titulo: { type: String, required: true },
  autor: { type: String, required: true },
  mensaje: { type: String, required: true },
  prioridad: { type: String, default: 'Normal' },
  fecha: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Notice', noticeSchema);