const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  titulo: { type: String, required: true },
  materia: { type: String, required: true },
  descripcion: { type: String, required: true },
  fechaEntrega: { type: String, required: true },
  estatus: { type: String, default: 'Pendiente' } 
});

module.exports = mongoose.model('Task', taskSchema);