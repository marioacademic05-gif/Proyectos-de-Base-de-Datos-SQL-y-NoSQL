<?php
/**
 * CRUD de categorías. Eliminar falla si la categoría tiene libros (FK RESTRICT).
 */
require_once __DIR__ . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $id = (int)($_POST['id'] ?? 0);
    try {
        if (($_POST['accion'] ?? '') === 'guardar') {
            $nombre = post_texto('nombre');
            if ($nombre === '' || mb_strlen($nombre) > 60) {
                throw new InvalidArgumentException('El nombre es obligatorio (máximo 60 caracteres).');
            }
            if ($id > 0) {
                db()->prepare('UPDATE categorias SET nombre = ? WHERE id_categoria = ?')->execute([$nombre, $id]);
                flash('success', 'Categoría actualizada.');
            } else {
                db()->prepare('INSERT INTO categorias (nombre) VALUES (?)')->execute([$nombre]);
                flash('success', 'Categoría registrada.');
            }
        } elseif (($_POST['accion'] ?? '') === 'eliminar') {
            db()->prepare('DELETE FROM categorias WHERE id_categoria = ?')->execute([$id]);
            flash('success', 'Categoría eliminada.');
        }
    } catch (InvalidArgumentException $e) {
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        flash('danger', mensaje_error_bd($e));
    }
    redirigir('categorias.php');
}

// libros y ejemplares por categoría
$categorias = db()->query(
    'SELECT c.id_categoria, c.nombre, COUNT(DISTINCT l.id_libro) AS libros, COUNT(e.id_ejemplar) AS ejemplares
     FROM categorias c
     LEFT JOIN libros l     ON l.id_categoria = c.id_categoria
     LEFT JOIN ejemplares e ON e.id_libro = l.id_libro
     GROUP BY c.id_categoria, c.nombre
     ORDER BY c.nombre'
)->fetchAll();

$titulo = 'Categorías';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-tags"></i> Categorías</h1>
  <button class="btn btn-primario" data-bs-toggle="modal" data-bs-target="#modalCategoria" data-editar="#modalCategoria" data-registro="{}">
    <i class="bi bi-plus-lg"></i> Nueva categoría
  </button>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light"><tr><th>Nombre</th><th class="text-center">Libros</th><th class="text-center">Ejemplares</th><th class="text-end">Acciones</th></tr></thead>
      <tbody>
      <?php foreach ($categorias as $c): ?>
        <tr>
          <td class="fw-semibold"><?= e($c['nombre']) ?></td>
          <td class="text-center"><span class="badge text-bg-secondary"><?= (int)$c['libros'] ?></span></td>
          <td class="text-center"><span class="badge text-bg-light"><?= (int)$c['ejemplares'] ?></span></td>
          <td class="text-end text-nowrap">
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalCategoria" data-editar="#modalCategoria"
                    data-registro='<?= e(json_encode(['id' => $c['id_categoria'], 'nombre' => $c['nombre']])) ?>'>
              <i class="bi bi-pencil"></i><span class="visually-hidden">Editar</span></button>
            <form method="post" class="d-inline" data-confirmar="¿Eliminar la categoría «<?= e($c['nombre']) ?>»?">
              <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= (int)$c['id_categoria'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i><span class="visually-hidden">Eliminar</span></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="modalCategoria" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content needs-validation" novalidate>
      <?= csrf_campo() ?><input type="hidden" name="accion" value="guardar"><input type="hidden" name="id">
      <div class="modal-header"><h2 class="modal-title h5">Nuevo</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button></div>
      <div class="modal-body">
        <label class="form-label" for="cat-nombre">Nombre *</label>
        <input class="form-control" id="cat-nombre" name="nombre" maxlength="60" required>
        <div class="invalid-feedback">Escribe el nombre.</div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primario"><i class="bi bi-save"></i> Guardar</button></div>
    </form>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
