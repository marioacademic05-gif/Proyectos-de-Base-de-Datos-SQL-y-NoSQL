<?php
/**
 * CRUD de libros con sus autores (relación N:M) y ejemplares iniciales.
 * Alta, edición y eliminación se hacen en TRANSACCIONES porque tocan varias tablas.
 */
require_once __DIR__ . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $id  = (int)($_POST['id'] ?? 0);
    $pdo = db();
    try {
        if (($_POST['accion'] ?? '') === 'guardar') {
            $isbn       = strtoupper(str_replace(' ', '', post_texto('isbn')));
            $titulo     = post_texto('titulo');
            $categoria  = (int)($_POST['id_categoria'] ?? 0);
            $editorial  = vacio_a_null(post_texto('editorial'));
            $anio       = post_texto('anio_publicacion') === '' ? null : filter_var($_POST['anio_publicacion'], FILTER_VALIDATE_INT);
            $autores    = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['autores'] ?? [])))));
            $copias     = $id > 0 ? 0 : (int)($_POST['copias'] ?? 0);
            $ubicacion  = vacio_a_null(post_texto('ubicacion'));

            $errores = [];
            $digitos = str_replace('-', '', $isbn);
            if (!preg_match('/^[0-9-]+X?$/', $isbn) || !in_array(strlen($digitos), [10, 13], true)) $errores[] = 'El ISBN debe tener 10 o 13 dígitos (se permiten guiones).';
            if ($titulo === '' || mb_strlen($titulo) > 150) $errores[] = 'El título es obligatorio (máximo 150 caracteres).';
            if ($categoria <= 0)  $errores[] = 'Selecciona una categoría.';
            if ($anio === false || ($anio !== null && ($anio < 1450 || $anio > (int)date('Y') + 1))) $errores[] = 'El año de publicación no es válido.';
            if (!$autores)        $errores[] = 'Selecciona al menos un autor.';
            if ($copias < 0 || $copias > 20) $errores[] = 'Los ejemplares iniciales deben ser de 0 a 20.';
            if ($errores) throw new InvalidArgumentException(implode(' ', $errores));

            $pdo->beginTransaction();
            if ($id > 0) {
                $pdo->prepare('UPDATE libros SET isbn = ?, titulo = ?, id_categoria = ?, editorial = ?, anio_publicacion = ? WHERE id_libro = ?')
                    ->execute([$isbn, $titulo, $categoria, $editorial, $anio, $id]);
                $pdo->prepare('DELETE FROM libro_autor WHERE id_libro = ?')->execute([$id]);
            } else {
                $pdo->prepare('INSERT INTO libros (isbn, titulo, id_categoria, editorial, anio_publicacion) VALUES (?, ?, ?, ?, ?)')
                    ->execute([$isbn, $titulo, $categoria, $editorial, $anio]);
                $id = (int)$pdo->lastInsertId();
            }
            $ins = $pdo->prepare('INSERT INTO libro_autor (id_libro, id_autor) VALUES (?, ?)');
            foreach ($autores as $a) $ins->execute([$id, $a]);

            // Ejemplares iniciales con código de inventario consecutivo
            $insE = $pdo->prepare('INSERT INTO ejemplares (id_libro, codigo_inventario, ubicacion) VALUES (?, ?, ?)');
            for ($n = 1; $n <= $copias; $n++) {
                $insE->execute([$id, sprintf('L%04d-%02d', $id, $n), $ubicacion]);
            }
            $pdo->commit();
            flash('success', $copias ? "Libro guardado con $copias ejemplar(es)." : 'Libro guardado.');
        } elseif (($_POST['accion'] ?? '') === 'eliminar') {
            // Se borran sus ejemplares y el libro; si algún ejemplar tiene préstamos, la FK lo impide y se hace ROLLBACK.
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM ejemplares WHERE id_libro = ?')->execute([$id]);
            $pdo->prepare('DELETE FROM libros WHERE id_libro = ?')->execute([$id]);
            $pdo->commit();
            flash('success', 'Libro eliminado junto con sus ejemplares.');
        }
    } catch (InvalidArgumentException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $msg = mensaje_error_bd($e);
        if (($e->errorInfo[1] ?? 0) === 1451) $msg = 'No se puede eliminar: el libro tiene historial de préstamos. Puedes dar de baja sus ejemplares.';
        flash('danger', $msg);
    }
    redirigir('libros.php?' . http_build_query(array_filter(['q' => $_GET['q'] ?? '', 'cat' => $_GET['cat'] ?? ''])));
}

// ---------- Listado con filtros ----------
$q   = trim($_GET['q'] ?? '');
$cat = (int)($_GET['cat'] ?? 0);

$sql = "SELECT l.*, c.nombre AS categoria,
               (SELECT GROUP_CONCAT(CONCAT(a.nombre, ' ', a.apellidos) ORDER BY a.apellidos SEPARATOR ', ')
                  FROM libro_autor la JOIN autores a ON a.id_autor = la.id_autor
                 WHERE la.id_libro = l.id_libro) AS autores_txt,
               (SELECT GROUP_CONCAT(la.id_autor) FROM libro_autor la WHERE la.id_libro = l.id_libro) AS autores_ids,
               (SELECT COUNT(*) FROM v_ejemplares v WHERE v.id_libro = l.id_libro AND v.disponibilidad = 'Disponible') AS disponibles,
               (SELECT COUNT(*) FROM ejemplares e WHERE e.id_libro = l.id_libro AND e.estado <> 'Baja') AS total
        FROM libros l
        JOIN categorias c ON c.id_categoria = l.id_categoria
        WHERE 1 = 1";
$p = [];
if ($q !== '') {
    $sql .= ' AND (l.titulo LIKE ? OR l.isbn = ? OR EXISTS (SELECT 1 FROM libro_autor la JOIN autores a ON a.id_autor = la.id_autor
              WHERE la.id_libro = l.id_libro AND CONCAT(a.nombre, " ", a.apellidos) LIKE ?))';
    array_push($p, "%$q%", $q, "%$q%");
}
if ($cat > 0) { $sql .= ' AND l.id_categoria = ?'; $p[] = $cat; }
$sql .= ' ORDER BY l.titulo';
$stmt = db()->prepare($sql);
$stmt->execute($p);
$libros = $stmt->fetchAll();

$categorias = db()->query('SELECT id_categoria, nombre FROM categorias ORDER BY nombre')->fetchAll();
$autores    = db()->query("SELECT id_autor, CONCAT(apellidos, ', ', nombre) AS nombre FROM autores ORDER BY apellidos, nombre")->fetchAll();

$titulo = 'Libros';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-book"></i> Libros</h1>
  <button class="btn btn-primario" data-bs-toggle="modal" data-bs-target="#modalLibro" data-editar="#modalLibro" data-registro="{}"><i class="bi bi-plus-lg"></i> Nuevo libro</button>
</div>

<form class="row g-2 mb-3" method="get">
  <div class="col-md-6"><input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Buscar por título, autor o ISBN" aria-label="Buscar"></div>
  <div class="col-md-4">
    <select class="form-select" name="cat" aria-label="Categoría">
      <option value="">Todas las categorías</option>
      <?php foreach ($categorias as $c): ?><option value="<?= $c['id_categoria'] ?>" <?= $cat === (int)$c['id_categoria'] ? 'selected' : '' ?>><?= e($c['nombre']) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="col-md-2 d-grid"><button class="btn btn-outline-secondary"><i class="bi bi-search"></i> Buscar</button></div>
</form>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light"><tr><th>ISBN</th><th>Título</th><th>Autor(es)</th><th>Categoría</th><th class="text-center">Disponibles</th><th class="text-end">Acciones</th></tr></thead>
      <tbody>
      <?php foreach ($libros as $l): ?>
        <tr>
          <td class="font-monospace small"><?= e($l['isbn']) ?></td>
          <td><a class="fw-semibold text-decoration-none" href="libro_detalle.php?id=<?= (int)$l['id_libro'] ?>"><?= e($l['titulo']) ?></a>
              <div class="small text-body-secondary"><?= e($l['editorial']) ?> <?= $l['anio_publicacion'] ? '· ' . (int)$l['anio_publicacion'] : '' ?></div></td>
          <td class="small"><?= e($l['autores_txt']) ?></td>
          <td><?= e($l['categoria']) ?></td>
          <td class="text-center"><span class="badge <?= $l['disponibles'] > 0 ? 'text-bg-success' : 'text-bg-danger' ?>"><?= (int)$l['disponibles'] ?> / <?= (int)$l['total'] ?></span></td>
          <td class="text-end text-nowrap">
            <a class="btn btn-sm btn-outline-secondary" href="libro_detalle.php?id=<?= (int)$l['id_libro'] ?>"><i class="bi bi-eye"></i><span class="visually-hidden">Ver</span></a>
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalLibro" data-editar="#modalLibro"
                    data-registro='<?= e(json_encode(['id' => $l['id_libro'], 'isbn' => $l['isbn'], 'titulo' => $l['titulo'], 'id_categoria' => $l['id_categoria'],
                        'editorial' => $l['editorial'], 'anio_publicacion' => $l['anio_publicacion'], 'autores' => explode(',', (string)$l['autores_ids'])])) ?>'>
              <i class="bi bi-pencil"></i><span class="visually-hidden">Editar</span></button>
            <form method="post" class="d-inline" data-confirmar="¿Eliminar «<?= e($l['titulo']) ?>» y sus ejemplares?">
              <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= (int)$l['id_libro'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i><span class="visually-hidden">Eliminar</span></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$libros): ?><tr><td colspan="6" class="text-center text-body-secondary py-4">No se encontraron libros.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer bg-white small text-body-secondary"><?= count($libros) ?> libro(s)</div>
</div>

<div class="modal fade" id="modalLibro" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <form method="post" class="modal-content needs-validation" novalidate>
      <?= csrf_campo() ?><input type="hidden" name="accion" value="guardar"><input type="hidden" name="id">
      <div class="modal-header"><h2 class="modal-title h5">Nuevo</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button></div>
      <div class="modal-body row g-3">
        <div class="col-md-4"><label class="form-label" for="l-isbn">ISBN *</label><input class="form-control" id="l-isbn" name="isbn" pattern="[0-9\-]{10,17}X?" required><div class="invalid-feedback">10 o 13 dígitos.</div></div>
        <div class="col-md-8"><label class="form-label" for="l-tit">Título *</label><input class="form-control" id="l-tit" name="titulo" maxlength="150" required></div>
        <div class="col-md-4">
          <label class="form-label" for="l-cat">Categoría *</label>
          <select class="form-select" id="l-cat" name="id_categoria" required><option value="">Selecciona…</option>
            <?php foreach ($categorias as $c): ?><option value="<?= $c['id_categoria'] ?>"><?= e($c['nombre']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-5"><label class="form-label" for="l-edit">Editorial</label><input class="form-control" id="l-edit" name="editorial" maxlength="80"></div>
        <div class="col-md-3"><label class="form-label" for="l-anio">Año</label><input class="form-control" id="l-anio" name="anio_publicacion" type="number" min="1450" max="<?= date('Y') + 1 ?>"></div>
        <div class="col-12">
          <label class="form-label" for="l-aut">Autor(es) * <small class="text-body-secondary">(Ctrl + clic para elegir varios)</small></label>
          <select class="form-select" id="l-aut" name="autores[]" multiple size="6" required>
            <?php foreach ($autores as $a): ?><option value="<?= $a['id_autor'] ?>"><?= e($a['nombre']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4"><label class="form-label" for="l-cop">Ejemplares iniciales <small class="text-body-secondary">(solo alta)</small></label><input class="form-control" id="l-cop" name="copias" type="number" min="0" max="20" value="1"></div>
        <div class="col-md-8"><label class="form-label" for="l-ubi">Ubicación de los ejemplares</label><input class="form-control" id="l-ubi" name="ubicacion" maxlength="30" placeholder="Ej. Estante A3"></div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primario"><i class="bi bi-save"></i> Guardar</button></div>
    </form>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
