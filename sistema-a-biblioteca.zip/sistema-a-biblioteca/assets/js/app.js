// Comportamiento común de las páginas de la Biblioteca.

// Confirmación antes de enviar formularios con data-confirmar
document.addEventListener('submit', (evento) => {
  const mensaje = evento.target.dataset.confirmar;
  if (mensaje && !confirm(mensaje)) evento.preventDefault();
});

// Validación de Bootstrap
document.querySelectorAll('form.needs-validation').forEach((form) => {
  form.addEventListener('submit', (evento) => {
    if (!form.checkValidity()) {
      evento.preventDefault();
      evento.stopPropagation();
    }
    form.classList.add('was-validated');
  });
});

// Llena el modal de edición con los datos del botón (data-registro = JSON)
document.querySelectorAll('[data-editar]').forEach((boton) => {
  boton.addEventListener('click', () => {
    const modal = document.querySelector(boton.dataset.editar);
    const datos = JSON.parse(boton.dataset.registro || '{}');
    const form = modal.querySelector('form');
    form.reset();
    form.classList.remove('was-validated');
    Object.entries(datos).forEach(([campo, valor]) => {
      const input = form.elements[campo] || form.elements[campo + '[]'];
      if (!input) return;
      if (input.type === 'checkbox') input.checked = Number(valor) === 1;
      else if (input.multiple) [...input.options].forEach((o) => { o.selected = (valor || []).map(String).includes(o.value); });
      else input.value = valor ?? '';
    });
    modal.querySelector('.modal-title').textContent = datos.id ? 'Editar' : 'Nuevo';
  });
});

// Filtro rápido de tablas: <input data-filtro="#idTabla">
document.querySelectorAll('[data-filtro]').forEach((input) => {
  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    document.querySelectorAll(input.dataset.filtro + ' tbody tr').forEach((tr) => {
      tr.classList.toggle('d-none', q !== '' && !tr.textContent.toLowerCase().includes(q));
    });
  });
});
