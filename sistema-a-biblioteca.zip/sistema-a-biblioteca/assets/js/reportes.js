// Gráficas de la página de reportes (Chart.js)
const g = window.GRAFICAS;
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

new Chart(document.getElementById('graficaMes'), {
  type: 'bar',
  data: {
    labels: g.meses.map((m) => MESES[Number(m.slice(5, 7)) - 1] + ' ' + m.slice(2, 4)),
    datasets: [{ label: 'Préstamos', data: g.totales, backgroundColor: '#14594a', borderRadius: 4 }],
  },
  options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
});

new Chart(document.getElementById('graficaCategoria'), {
  type: 'bar',
  data: { labels: g.categorias, datasets: [{ data: g.porCategoria, backgroundColor: '#c8862b', borderRadius: 4 }] },
  options: { indexAxis: 'y', plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { ticks: { autoSkip: false } } } },
});
