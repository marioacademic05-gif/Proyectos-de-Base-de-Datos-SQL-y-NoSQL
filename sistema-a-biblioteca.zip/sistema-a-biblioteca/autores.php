<?php
require_once __DIR__ . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $id = (int)($_POST['id'] ?? 0);
    try {
        if (($_POST['accion'] ?? '') === 'guardar') {
            $nombre       = post_texto('nombre');
            $apellidos    = post_texto('apellidos');
            $nacionalidad = vacio_a_null(post_texto('nacionalidad'));
            $errores = [];
            if ($nombre === '' || mb_strlen($nombre) > 60)       $errores[] = 'El nombre es obligatorio.';
            if ($apellidos === '' || mb_strlen($apellidos) > 80) $errores[] = 'Los apellidos son obligatorios.';
            if ($errores) throw new InvalidArgumentException(implode(' ', $errores));

            if ($id > 0) {
                db()->prepare('UPDATE autores SET nombre = ?, apellidos = ?, nacionalidad = ? WHERE id_autor = ?')
                    ->execute([$nombre, $apellidos, $nacionalidad, $id]);
                flash('success', 'Autor actualizado.');
            } else {
                db()->prepare('INSERT INTO autores (nombre, apellidos, nacionalidad) VALUES (?, ?, ?)')
                    ->execute([$nombre, $apellidos, $nacionalidad]);
                flash('success', 'Autor registrado.');
            }
        } elseif (($_POST['accion'] ?? '') === 'eliminar') {
            db()->prepare('DELETE FROM autores WHERE id_autor = ?')->execute([$id]);
            flash('success', 'Autor eliminado.');
        }
    } catch (InvalidArgumentException $e) {
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        flash('danger', mensaje_error_bd($e));
    }
    redirigir('autores.php');
}

$autores = db()->query(
    'SELECT a.*, COUNT(la.id_libro) AS libros,
            GROUP_CONCAT(l.titulo ORDER BY l.titulo SEPARATOR " · ") AS titulos
     FROM autores a
     LEFT JOIN libro_autor la ON la.id_autor = a.id_autor
     LEFT JOIN libros l       ON l.id_libro  = la.id_libro
     GROUP BY a.id_autor
     ORDER BY a.apellidos, a.nombre'
)->fetchAll();

$titulo = 'Autores';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-pen"></i> Autores</h1>
  <div class="d-flex gap-2">
    <input class="form-control" type="search" placeholder="Filtrar…" data-filtro="#tablaAutores" aria-label="Filtrar autores">
    <button class="btn btn-primario text-nowrap" data-bs-toggle="modal" data-bs-target="#modalAutor" data-editar="#modalAutor" data-registro="{}"><i class="bi bi-plus-lg"></i> Nuevo autor</button>
  </div>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0" id="tablaAutores">
      <thead class="table-light"><tr><th>Autor</th><th>Nacionalidad</th><th>Libros en el acervo</th><th class="text-end">Acciones</th></tr></thead>
      <tbody>
      <?php foreach ($autores as $a): ?>
        <tr>
          <td class="fw-semibold"><?= e($a['apellidos'] . ', ' . $a['nombre']) ?></td>
          <td><?= e($a['nacionalidad']) ?></td>
          <td class="small"><span class="badge text-bg-secondary me-1"><?= (int)$a['libros'] ?></span><?= e($a['titulos']) ?></td>
          <td class="text-end text-nowrap">
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalAutor" data-editar="#modalAutor"
                    data-registro='<?= e(json_encode(['id' => $a['id_autor'], 'nombre' => $a['nombre'], 'apellidos' => $a['apellidos'], 'nacionalidad' => $a['nacionalidad']])) ?>'>
              <i class="bi bi-pencil"></i><span class="visually-hidden">Editar</span></button>
            <form method="post" class="d-inline" data-confirmar="¿Eliminar al autor «<?= e($a['nombre'] . ' ' . $a['apellidos']) ?>»?">
              <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= (int)$a['id_autor'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i><span class="visually-hidden">Eliminar</span></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="modalAutor" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content needs-validation" novalidate>
      <?= csrf_campo() ?><input type="hidden" name="accion" value="guardar"><input type="hidden" name="id">
      <div class="modal-header"><h2 class="modal-title h5">Nuevo</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button></div>
      <div class="modal-body row g-3">
        <div class="col-md-5"><label class="form-label" for="a-nombre">Nombre *</label><input class="form-control" id="a-nombre" name="nombre" maxlength="60" required></div>
        <div class="col-md-7"><label class="form-label" for="a-ape">Apellidos *</label><input class="form-control" id="a-ape" name="apellidos" maxlength="80" required></div>
        <div class="col-12"><label class="form-label" for="a-nac">Nacionalidad</label><input class="form-control" id="a-nac" name="nacionalidad" maxlength="40"></div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primario"><i class="bi bi-save"></i> Guardar</button></div>
    </form>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
