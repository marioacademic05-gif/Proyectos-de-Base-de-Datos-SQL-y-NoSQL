<?php
/**
 * Detalle de un libro: datos, ejemplares (alta, cambio de estado, baja) e historial de préstamos.
 */
require_once __DIR__ . '/includes/funciones.php';

const ESTADOS_EJEMPLAR = ['Disponible', 'Mantenimiento', 'Baja'];
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $accion = $_POST['accion'] ?? '';
    try {
        if ($accion === 'agregar_ejemplar') {
            $codigo    = strtoupper(post_texto('codigo_inventario'));
            $ubicacion = vacio_a_null(post_texto('ubicacion'));
            if (!preg_match('/^[A-Z0-9-]{3,20}$/', $codigo)) throw new InvalidArgumentException('Código de inventario inválido (3 a 20 letras, números o guion).');
            db()->prepare('INSERT INTO ejemplares (id_libro, codigo_inventario, ubicacion) VALUES (?, ?, ?)')->execute([$id, $codigo, $ubicacion]);
            flash('success', "Ejemplar $codigo agregado.");
        } elseif ($accion === 'estado') {
            $estado = (string)($_POST['estado'] ?? '');
            $idEj   = (int)($_POST['id_ejemplar'] ?? 0);
            if (!in_array($estado, ESTADOS_EJEMPLAR, true)) throw new InvalidArgumentException('Estado inválido.');
            // No se puede mandar a mantenimiento o baja un ejemplar que está prestado
            $stmt = db()->prepare('SELECT COUNT(*) FROM prestamos WHERE id_ejemplar = ? AND fecha_devolucion IS NULL');
            $stmt->execute([$idEj]);
            if ($estado !== 'Disponible' && $stmt->fetchColumn()) throw new InvalidArgumentException('El ejemplar está prestado; primero registra la devolución.');
            db()->prepare('UPDATE ejemplares SET estado = ? WHERE id_ejemplar = ? AND id_libro = ?')->execute([$estado, $idEj, $id]);
            flash('success', 'Estado del ejemplar actualizado.');
        } elseif ($accion === 'eliminar_ejemplar') {
            db()->prepare('DELETE FROM ejemplares WHERE id_ejemplar = ? AND id_libro = ?')->execute([(int)$_POST['id_ejemplar'], $id]);
            flash('success', 'Ejemplar eliminado.');
        }
    } catch (InvalidArgumentException $e) {
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        $msg = mensaje_error_bd($e);
        if (($e->errorInfo[1] ?? 0) === 1451) $msg = 'El ejemplar tiene historial de préstamos; en lugar de eliminarlo márcalo como «Baja».';
        flash('danger', $msg);
    }
    redirigir('libro_detalle.php?id=' . $id);
}

$stmt = db()->prepare('SELECT l.*, c.nombre AS categoria FROM libros l JOIN categorias c ON c.id_categoria = l.id_categoria WHERE l.id_libro = ?');
$stmt->execute([$id]);
$libro = $stmt->fetch();
if (!$libro) { flash('warning', 'El libro no existe.'); redirigir('libros.php'); }

$stmt = db()->prepare('SELECT a.* FROM autores a JOIN libro_autor la ON la.id_autor = a.id_autor WHERE la.id_libro = ? ORDER BY a.apellidos');
$stmt->execute([$id]);
$autores = $stmt->fetchAll();

$stmt = db()->prepare('SELECT * FROM v_ejemplares WHERE id_libro = ? ORDER BY codigo_inventario');
$stmt->execute([$id]);
$ejemplares = $stmt->fetchAll();

$stmt = db()->prepare('SELECT * FROM v_prestamos WHERE id_libro = ? ORDER BY fecha_prestamo DESC LIMIT 20');
$stmt->execute([$id]);
$historial = $stmt->fetchAll();

$titulo = $libro['titulo'];
require __DIR__ . '/includes/header.php';
?>
<nav aria-label="breadcrumb"><ol class="breadcrumb"><li class="breadcrumb-item"><a href="libros.php">Libros</a></li><li class="breadcrumb-item active" aria-current="page"><?= e($libro['titulo']) ?></li></ol></nav>

<div class="row g-3 mb-3">
  <div class="col-md-3"><div class="portada-libro"><i class="bi bi-book"></i></div></div>
  <div class="col-md-9">
    <h1 class="h3 mb-1"><?= e($libro['titulo']) ?></h1>
    <div class="text-body-secondary mb-2"><?= e(implode(', ', array_map(fn($a) => $a['nombre'] . ' ' . $a['apellidos'], $autores))) ?></div>
    <dl class="row small mb-0">
      <dt class="col-4 col-md-2">ISBN</dt><dd class="col-8 col-md-4 font-monospace"><?= e($libro['isbn']) ?></dd>
      <dt class="col-4 col-md-2">Categoría</dt><dd class="col-8 col-md-4"><?= e($libro['categoria']) ?></dd>
      <dt class="col-4 col-md-2">Editorial</dt><dd class="col-8 col-md-4"><?= e($libro['editorial']) ?></dd>
      <dt class="col-4 col-md-2">Año</dt><dd class="col-8 col-md-4"><?= e((string)$libro['anio_publicacion']) ?></dd>
    </dl>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card h-100">
      <div class="card-header bg-white fw-semibold">Ejemplares (<?= count($ejemplares) ?>)</div>
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light"><tr><th>Código</th><th>Ubicación</th><th>Disponibilidad</th><th>Estado físico</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($ejemplares as $ej): ?>
            <tr>
              <td class="font-monospace"><?= e($ej['codigo_inventario']) ?></td>
              <td><?= e($ej['ubicacion']) ?></td>
              <td><?= badge_estado($ej['disponibilidad']) ?></td>
              <td>
                <form method="post" class="d-flex gap-1">
                  <?= csrf_campo() ?><input type="hidden" name="accion" value="estado"><input type="hidden" name="id_ejemplar" value="<?= (int)$ej['id_ejemplar'] ?>">
                  <select class="form-select form-select-sm" name="estado" aria-label="Estado físico" onchange="this.form.submit()">
                    <?php foreach (ESTADOS_EJEMPLAR as $es): ?><option <?= $ej['estado'] === $es ? 'selected' : '' ?>><?= $es ?></option><?php endforeach; ?>
                  </select>
                </form>
              </td>
              <td class="text-end">
                <form method="post" data-confirmar="¿Eliminar el ejemplar <?= e($ej['codigo_inventario']) ?>?">
                  <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar_ejemplar"><input type="hidden" name="id_ejemplar" value="<?= (int)$ej['id_ejemplar'] ?>">
                  <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i><span class="visually-hidden">Eliminar</span></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <form method="post" class="card-footer bg-white row g-2 align-items-end mx-0">
        <?= csrf_campo() ?><input type="hidden" name="accion" value="agregar_ejemplar">
        <div class="col-sm-4"><label class="form-label small" for="nuevo-cod">Código</label><input class="form-control form-control-sm" id="nuevo-cod" name="codigo_inventario" required maxlength="20" placeholder="Ej. BD-0010"></div>
        <div class="col-sm-5"><label class="form-label small" for="nuevo-ubi">Ubicación</label><input class="form-control form-control-sm" id="nuevo-ubi" name="ubicacion" maxlength="30"></div>
        <div class="col-sm-3 d-grid"><button class="btn btn-sm btn-primario"><i class="bi bi-plus-lg"></i> Agregar</button></div>
      </form>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card h-100">
      <div class="card-header bg-white fw-semibold">Historial de préstamos</div>
      <ul class="list-group list-group-flush tabla-scroll">
        <?php foreach ($historial as $h): ?>
          <li class="list-group-item d-flex justify-content-between align-items-start">
            <span><?= e($h['socio']) ?><br><small class="text-body-secondary"><?= e($h['codigo_inventario']) ?> · <?= fecha($h['fecha_prestamo']) ?> → <?= $h['fecha_devolucion'] ? fecha($h['fecha_devolucion']) : 'sin devolver' ?></small></span>
            <?= badge_estado($h['estado']) ?>
          </li>
        <?php endforeach; ?>
        <?php if (!$historial): ?><li class="list-group-item text-body-secondary text-center py-4">Este libro aún no se ha prestado.</li><?php endif; ?>
      </ul>
    </div>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
