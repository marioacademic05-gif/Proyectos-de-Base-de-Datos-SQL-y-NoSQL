<?php
/**
 * CRUD de socios. Muestra préstamos activos y multas pendientes (subconsultas).
 */
require_once __DIR__ . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $id = (int)($_POST['id'] ?? 0);
    try {
        if (($_POST['accion'] ?? '') === 'guardar') {
            $matricula = strtoupper(post_texto('matricula'));
            $nombre    = post_texto('nombre');
            $apellidos = post_texto('apellidos');
            $email     = vacio_a_null(mb_strtolower(post_texto('email')));
            $telefono  = vacio_a_null(post_texto('telefono'));
            $tipo      = (int)($_POST['id_tipo'] ?? 0);
            $activo    = isset($_POST['activo']) ? 1 : 0;

            $errores = [];
            if (!preg_match('/^[A-Z0-9]{4,15}$/', $matricula))                $errores[] = 'La matrícula debe tener de 4 a 15 letras o números.';
            if ($nombre === '' || mb_strlen($nombre) > 60)                   $errores[] = 'El nombre es obligatorio.';
            if ($apellidos === '' || mb_strlen($apellidos) > 80)             $errores[] = 'Los apellidos son obligatorios.';
            if ($email !== null && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errores[] = 'El correo no es válido.';
            if ($telefono !== null && !preg_match('/^[0-9]{10}$/', $telefono)) $errores[] = 'El teléfono debe tener 10 dígitos.';
            if ($tipo <= 0)                                                  $errores[] = 'Selecciona el tipo de socio.';
            if ($errores) throw new InvalidArgumentException(implode(' ', $errores));

            $v = [$matricula, $nombre, $apellidos, $email, $telefono, $tipo, $activo];
            if ($id > 0) {
                db()->prepare('UPDATE socios SET matricula = ?, nombre = ?, apellidos = ?, email = ?, telefono = ?, id_tipo = ?, activo = ? WHERE id_socio = ?')->execute([...$v, $id]);
                flash('success', 'Socio actualizado.');
            } else {
                db()->prepare('INSERT INTO socios (matricula, nombre, apellidos, email, telefono, id_tipo, activo) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute($v);
                flash('success', 'Socio registrado.');
            }
        } elseif (($_POST['accion'] ?? '') === 'eliminar') {
            db()->prepare('DELETE FROM socios WHERE id_socio = ?')->execute([$id]);
            flash('success', 'Socio eliminado.');
        }
    } catch (InvalidArgumentException $e) {
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        $msg = mensaje_error_bd($e);
        if (($e->errorInfo[1] ?? 0) === 1451) $msg = 'El socio tiene historial de préstamos; puedes desactivarlo en lugar de eliminarlo.';
        flash('danger', $msg);
    }
    redirigir('socios.php');
}

$socios = db()->query(
    "SELECT s.*, t.nombre AS tipo, t.max_prestamos,
            (SELECT COUNT(*) FROM prestamos p WHERE p.id_socio = s.id_socio AND p.fecha_devolucion IS NULL) AS activos,
            (SELECT COALESCE(SUM(p.multa), 0) FROM prestamos p WHERE p.id_socio = s.id_socio AND p.multa > 0 AND p.multa_pagada = 0) AS adeudo
     FROM socios s
     JOIN tipos_socio t ON t.id_tipo = s.id_tipo
     ORDER BY s.activo DESC, s.apellidos, s.nombre"
)->fetchAll();
$tipos = db()->query('SELECT * FROM tipos_socio ORDER BY id_tipo')->fetchAll();

$titulo = 'Socios';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-person-vcard"></i> Socios</h1>
  <div class="d-flex gap-2">
    <input class="form-control" type="search" placeholder="Filtrar…" data-filtro="#tablaSocios" aria-label="Filtrar socios">
    <button class="btn btn-primario text-nowrap" data-bs-toggle="modal" data-bs-target="#modalSocio" data-editar="#modalSocio" data-registro="{}"><i class="bi bi-person-plus"></i> Nuevo socio</button>
  </div>
</div>

<div class="row g-2 mb-3">
  <?php foreach ($tipos as $t): ?>
    <div class="col-md-4"><div class="reglas p-2 small"><strong><?= e($t['nombre']) ?>:</strong> hasta <?= (int)$t['max_prestamos'] ?> libro(s), <?= (int)$t['dias_prestamo'] ?> días, multa <?= dinero($t['multa_diaria']) ?> por día de retraso</div></div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0" id="tablaSocios">
      <thead class="table-light"><tr><th>Matrícula</th><th>Nombre</th><th>Tipo</th><th>Contacto</th><th class="text-center">Préstamos</th><th class="text-end">Adeudo</th><th class="text-end">Acciones</th></tr></thead>
      <tbody>
      <?php foreach ($socios as $s): ?>
        <tr class="<?= $s['activo'] ? '' : 'text-body-tertiary' ?>">
          <td class="font-monospace"><?= e($s['matricula']) ?></td>
          <td class="fw-semibold"><?= e($s['nombre'] . ' ' . $s['apellidos']) ?> <?= $s['activo'] ? '' : '<span class="badge text-bg-secondary">Inactivo</span>' ?></td>
          <td><?= e($s['tipo']) ?></td>
          <td class="small"><?= e($s['email']) ?><br><?= e($s['telefono']) ?></td>
          <td class="text-center"><span class="badge <?= $s['activos'] >= $s['max_prestamos'] ? 'text-bg-warning' : 'text-bg-secondary' ?>"><?= (int)$s['activos'] ?> / <?= (int)$s['max_prestamos'] ?></span></td>
          <td class="text-end <?= $s['adeudo'] > 0 ? 'text-danger fw-semibold' : 'text-body-secondary' ?>"><?= dinero($s['adeudo']) ?></td>
          <td class="text-end text-nowrap">
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#modalSocio" data-editar="#modalSocio"
                    data-registro='<?= e(json_encode(['id' => $s['id_socio'], 'matricula' => $s['matricula'], 'nombre' => $s['nombre'], 'apellidos' => $s['apellidos'],
                        'email' => $s['email'], 'telefono' => $s['telefono'], 'id_tipo' => $s['id_tipo'], 'activo' => $s['activo']])) ?>'>
              <i class="bi bi-pencil"></i><span class="visually-hidden">Editar</span></button>
            <form method="post" class="d-inline" data-confirmar="¿Eliminar a «<?= e($s['nombre']) ?>»?">
              <?= csrf_campo() ?><input type="hidden" name="accion" value="eliminar"><input type="hidden" name="id" value="<?= (int)$s['id_socio'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i><span class="visually-hidden">Eliminar</span></button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="modalSocio" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content needs-validation" novalidate>
      <?= csrf_campo() ?><input type="hidden" name="accion" value="guardar"><input type="hidden" name="id">
      <div class="modal-header"><h2 class="modal-title h5">Nuevo</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button></div>
      <div class="modal-body row g-3">
        <div class="col-md-5"><label class="form-label" for="s-mat">Matrícula *</label><input class="form-control text-uppercase" id="s-mat" name="matricula" pattern="[A-Za-z0-9]{4,15}" required><div class="invalid-feedback">4 a 15 letras o números.</div></div>
        <div class="col-md-7">
          <label class="form-label" for="s-tipo">Tipo *</label>
          <select class="form-select" id="s-tipo" name="id_tipo" required><?php foreach ($tipos as $t): ?><option value="<?= $t['id_tipo'] ?>"><?= e($t['nombre']) ?></option><?php endforeach; ?></select>
        </div>
        <div class="col-md-5"><label class="form-label" for="s-nom">Nombre *</label><input class="form-control" id="s-nom" name="nombre" maxlength="60" required></div>
        <div class="col-md-7"><label class="form-label" for="s-ape">Apellidos *</label><input class="form-control" id="s-ape" name="apellidos" maxlength="80" required></div>
        <div class="col-md-7"><label class="form-label" for="s-mail">Correo</label><input class="form-control" id="s-mail" name="email" type="email" maxlength="120"></div>
        <div class="col-md-5"><label class="form-label" for="s-tel">Teléfono</label><input class="form-control" id="s-tel" name="telefono" pattern="[0-9]{10}" inputmode="numeric"><div class="invalid-feedback">10 dígitos.</div></div>
        <div class="col-12"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="s-act" name="activo" value="1" checked><label class="form-check-label" for="s-act">Activo</label></div></div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button><button class="btn btn-primario"><i class="bi bi-save"></i> Guardar</button></div>
    </form>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
