<?php
/**
 * Conexión a MySQL con PDO.
 */

const DB_HOST = '127.0.0.1';
const DB_PORT = 3306;
const DB_NAME = 'biblioteca';
const DB_USER = 'root';
const DB_PASS = '';          

function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci',
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            exit('<h3 style="font-family:sans-serif">No se pudo conectar a la base de datos.</h3>'
               . '<p style="font-family:sans-serif">Verifica que MySQL esté iniciado y que hayas '
               . 'ejecutado los scripts de la carpeta <code>database/</code>.</p>');
        }
    }
    return $pdo;
}
