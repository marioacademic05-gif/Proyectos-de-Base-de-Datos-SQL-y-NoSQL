# Sistema A — Biblioteca (PHP + MySQL)

Sistema web para administrar una biblioteca escolar: libros con varios autores, ejemplares físicos,
socios con reglas por tipo (alumno, docente o externo), préstamos, devoluciones con cálculo
automático de multas y reportes.

| Capa | Tecnología |
|---|---|
| Frontend | HTML5, Bootstrap 5.3, Bootstrap Icons, JavaScript, Chart.js |
| Backend | PHP 8.3 (PDO) |
| Base de datos | MySQL 8.4 (InnoDB, utf8mb4) |
| Servidor local | Laragon (Apache + MySQL) |

## Funcionalidades

- **Tablero:** préstamos activos y vencidos, ejemplares disponibles, multas por cobrar y préstamos próximos a vencer.
- **Nuevo préstamo:** buscador de socio y de ejemplar. Antes de prestar se valida, **en una transacción
  con `SELECT … FOR UPDATE`**, que el socio:
  - esté activo,
  - no deba multas,
  - no tenga préstamos vencidos,
  - no rebase el máximo de su tipo.

  También se valida que el ejemplar esté disponible.
- **Devolución:** calcula los días de retraso y la multa según la tarifa del tipo de socio. También permite registrar el pago de la multa.
- **Libros:** CRUD con varios autores (relación N:M) y ejemplares iniciales en una sola transacción.
- **Detalle de libro:** ejemplares con su disponibilidad calculada, cambio de estado físico e historial.
- **CRUD** de socios, autores y categorías.
- **Reportes:** préstamos por mes y por categoría, top 5 de libros, puntualidad por tipo de socio,
  lectores por encima del promedio (`HAVING` + subconsulta) y libros nunca prestados (`NOT EXISTS`).

## Modelo de datos (3FN)

```
categorias  (PK id_categoria, nombre UQ)
autores     (PK id_autor, nombre, apellidos, nacionalidad)
libros      (PK id_libro, isbn UQ, titulo, FK id_categoria, editorial, anio_publicacion)
libro_autor (PK/FK id_libro, PK/FK id_autor)                 ← relación N:M
ejemplares  (PK id_ejemplar, FK id_libro, codigo_inventario UQ, ubicacion, estado)
tipos_socio (PK id_tipo, nombre UQ, max_prestamos, dias_prestamo, multa_diaria)
socios      (PK id_socio, matricula UQ, nombre, apellidos, email UQ, telefono, FK id_tipo, activo)
prestamos   (PK id_prestamo, FK id_ejemplar, FK id_socio, fecha_prestamo, fecha_limite,
             fecha_devolucion, multa, multa_pagada, prestamo_abierto [generada])
Vistas: v_ejemplares (disponibilidad calculada) · v_prestamos (estado, días de retraso, multa estimada)
```

Decisiones de diseño:
- Las reglas de préstamo (máximo, días y multa) dependen del **tipo** de socio, no del socio, así que van en `tipos_socio` (3FN).
- El estado "Prestado" de un ejemplar **no se guarda**: se deduce de los préstamos abiertos en la vista `v_ejemplares`.
- La `multa` sí se guarda al devolver, porque es un dato histórico: la tarifa puede cambiar después.
- La columna generada `prestamo_abierto` y el índice `UNIQUE (id_ejemplar, prestamo_abierto)` hacen que **MySQL impida dos préstamos abiertos del mismo ejemplar**, aunque falle la aplicación.

## Estructura

```
sistema-a-biblioteca/
├── config/db.php                  Conexión PDO
├── includes/                      funciones.php · header.php · footer.php
├── assets/css · assets/js         Estilos y scripts
├── database/01_esquema.sql        Tablas, llaves, CHECK, UNIQUE, índices y vistas
├── database/02_datos.sql          Datos de ejemplo
├── database/03_consultas.sql      Consultas para reportes y evidencias
├── index.php                      Tablero
├── prestamo_nuevo.php             Préstamo (transacción)
├── prestamos.php                  Listado, devolución y pago de multas
├── libros.php · libro_detalle.php
├── socios.php · autores.php · categorias.php
└── reportes.php
```

## Manual de instalación

**Requisitos:** Laragon con Apache, PHP 8.1 o superior (`pdo_mysql`) y MySQL 8.

1. Copia la carpeta `sistema-a-biblioteca` a `C:\laragon\www\`.
2. Abre Laragon y presiona **Iniciar todo**.
3. Abre HeidiSQL (botón **Base de datos**), ve a **Archivo → Ejecutar archivo SQL…** y ejecuta en orden:
   - `database\01_esquema.sql`
   - `database\02_datos.sql`
4. Abre `http://sistema-a-biblioteca.test` o `http://localhost/sistema-a-biblioteca`.

Alternativa sin Apache: dentro de la carpeta del proyecto ejecuta `php -S localhost:8082` y abre `http://localhost:8082`.

## Manual de uso

1. **Nuevo préstamo:** busca y selecciona al socio. El recuadro te dice si puede llevarse un libro. Luego elige un ejemplar disponible y presiona **Registrar préstamo**.
2. **Préstamos:** filtra por activos, vencidos, devueltos o con multa. **Devolver** calcula la multa automáticamente y **Pagar multa** la marca como cobrada.
3. **Libros:** **Nuevo libro** permite elegir varios autores (Ctrl + clic) y crear ejemplares. Entra a un libro para agregar ejemplares o cambiar su estado (Disponible, Mantenimiento o Baja).
4. **Socios, Autores, Categorías:** alta, edición y eliminación. Si tienen historial, el sistema no deja borrarlos.
5. **Reportes:** elige el periodo.

## Pruebas realizadas

| # | Caso | Esperado | Obtenido |
|---|---|---|---|
| 1 | Préstamo a socio sin restricciones | Se registra con fecha límite según su tipo | ✔ |
| 2 | Préstamo a socio con préstamos vencidos | Rechazado | ✔ |
| 3 | Préstamo a socio con multa sin pagar | Rechazado e indica el adeudo | ✔ |
| 4 | Socio externo pide un 2.º libro (máximo 1) | Rechazado | ✔ |
| 5 | Prestar un ejemplar ya prestado | Rechazado (y UNIQUE en la BD) | ✔ |
| 6 | Prestar un ejemplar en mantenimiento | Rechazado | ✔ |
| 7 | Devolver con 5 días de retraso (alumno) | Multa de $25.00 | ✔ |
| 8 | Devolver un préstamo ya devuelto | Aviso | ✔ |
| 9 | Libro con ISBN, título, año y autores inválidos | 5 mensajes de validación | ✔ |
| 10 | ISBN duplicado | Error 1062 traducido | ✔ |
| 11 | Eliminar libro con historial de préstamos | ROLLBACK y mensaje | ✔ |
| 12 | Mandar a mantenimiento un ejemplar prestado | Rechazado | ✔ |
| 13 | Eliminar categoría con libros | Bloqueado por FK | ✔ |
| 14 | POST sin token CSRF | HTTP 419 | ✔ |
