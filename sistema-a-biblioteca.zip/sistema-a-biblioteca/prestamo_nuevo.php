<?php
require_once __DIR__ . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $idSocio    = (int)($_POST['id_socio'] ?? 0);
    $idEjemplar = (int)($_POST['id_ejemplar'] ?? 0);
    $pdo = db();
    try {
        if ($idSocio <= 0 || $idEjemplar <= 0) throw new InvalidArgumentException('Selecciona el socio y el ejemplar.');

        $pdo->beginTransaction();

        // 1) Socio y reglas de su tipo (se bloquea la fila del socio)
        $stmt = $pdo->prepare(
            'SELECT s.id_socio, s.nombre, s.activo, t.max_prestamos, t.dias_prestamo
             FROM socios s JOIN tipos_socio t ON t.id_tipo = s.id_tipo
             WHERE s.id_socio = ? FOR UPDATE'
        );
        $stmt->execute([$idSocio]);
        $socio = $stmt->fetch();
        if (!$socio)           throw new InvalidArgumentException('El socio no existe.');
        if (!$socio['activo']) throw new InvalidArgumentException('El socio está inactivo.');

        $stmt = $pdo->prepare(
            "SELECT COUNT(*) AS activos,
                    SUM(CURDATE() > fecha_limite) AS vencidos
             FROM prestamos WHERE id_socio = ? AND fecha_devolucion IS NULL"
        );
        $stmt->execute([$idSocio]);
        $estado = $stmt->fetch();
        if ((int)$estado['vencidos'] > 0) throw new InvalidArgumentException('El socio tiene préstamos vencidos; primero debe devolverlos.');
        if ((int)$estado['activos'] >= (int)$socio['max_prestamos']) throw new InvalidArgumentException("El socio ya tiene el máximo de {$socio['max_prestamos']} préstamo(s).");

        $stmt = $pdo->prepare('SELECT COALESCE(SUM(multa), 0) FROM prestamos WHERE id_socio = ? AND multa > 0 AND multa_pagada = 0');
        $stmt->execute([$idSocio]);
        $adeudo = (float)$stmt->fetchColumn();
        if ($adeudo > 0) throw new InvalidArgumentException('El socio debe ' . dinero($adeudo) . ' en multas; debe pagarlas antes de un nuevo préstamo.');

        // 2) Ejemplar (se bloquea la fila para que nadie más lo preste al mismo tiempo)
        $stmt = $pdo->prepare(
            'SELECT e.estado, l.titulo FROM ejemplares e JOIN libros l ON l.id_libro = e.id_libro WHERE e.id_ejemplar = ? FOR UPDATE'
        );
        $stmt->execute([$idEjemplar]);
        $ejemplar = $stmt->fetch();
        if (!$ejemplar) throw new InvalidArgumentException('El ejemplar no existe.');
        if ($ejemplar['estado'] !== 'Disponible') throw new InvalidArgumentException("El ejemplar está en estado «{$ejemplar['estado']}».");

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM prestamos WHERE id_ejemplar = ? AND fecha_devolucion IS NULL');
        $stmt->execute([$idEjemplar]);
        if ($stmt->fetchColumn()) throw new InvalidArgumentException('Ese ejemplar ya está prestado.');

        // 3) Registrar el préstamo
        $pdo->prepare('INSERT INTO prestamos (id_ejemplar, id_socio, fecha_limite) VALUES (?, ?, CURDATE() + INTERVAL ? DAY)')
            ->execute([$idEjemplar, $idSocio, (int)$socio['dias_prestamo']]);

        $pdo->commit();
        $limite = date('d/m/Y', strtotime('+' . (int)$socio['dias_prestamo'] . ' days'));
        flash('success', "Préstamo registrado: «{$ejemplar['titulo']}» para {$socio['nombre']}. Fecha límite: $limite.");
        redirigir('prestamos.php');
    } catch (InvalidArgumentException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', mensaje_error_bd($e));
    }
    redirigir('prestamo_nuevo.php');
}

// ---------- Datos para el formulario ----------
$socios = db()->query(
    "SELECT s.id_socio, s.matricula, CONCAT(s.nombre, ' ', s.apellidos) AS nombre, t.nombre AS tipo, t.max_prestamos, t.dias_prestamo,
            (SELECT COUNT(*) FROM prestamos p WHERE p.id_socio = s.id_socio AND p.fecha_devolucion IS NULL) AS activos,
            (SELECT COUNT(*) FROM prestamos p WHERE p.id_socio = s.id_socio AND p.fecha_devolucion IS NULL AND CURDATE() > p.fecha_limite) AS vencidos,
            (SELECT COALESCE(SUM(p.multa), 0) FROM prestamos p WHERE p.id_socio = s.id_socio AND p.multa > 0 AND p.multa_pagada = 0) AS adeudo
     FROM socios s JOIN tipos_socio t ON t.id_tipo = s.id_tipo
     WHERE s.activo = 1 ORDER BY s.apellidos, s.nombre"
)->fetchAll();

$ejemplares = db()->query(
    "SELECT v.id_ejemplar, v.codigo_inventario, v.titulo, v.isbn, v.ubicacion
     FROM v_ejemplares v WHERE v.disponibilidad = 'Disponible' ORDER BY v.titulo, v.codigo_inventario"
)->fetchAll();

$titulo = 'Nuevo préstamo';
require __DIR__ . '/includes/header.php';
?>
<h1 class="h3 mb-3"><i class="bi bi-journal-plus"></i> Nuevo préstamo</h1>

<form method="post" class="row g-3">
  <?= csrf_campo() ?>
  <div class="col-lg-6">
    <div class="card h-100"><div class="card-body">
      <h2 class="h6">1. Socio</h2>
      <input class="form-control mb-2" type="search" placeholder="Buscar socio por nombre o matrícula" data-buscar="#selSocio" aria-label="Buscar socio">
      <select class="form-select" id="selSocio" name="id_socio" size="10" required>
        <?php foreach ($socios as $s):
            $bloqueado = $s['vencidos'] > 0 || $s['adeudo'] > 0 || $s['activos'] >= $s['max_prestamos']; ?>
          <option value="<?= $s['id_socio'] ?>" data-info='<?= e(json_encode($s)) ?>' <?= $bloqueado ? 'class="text-danger"' : '' ?>>
            <?= e($s['matricula'] . ' · ' . $s['nombre'] . ' (' . $s['tipo'] . ')') ?><?= $bloqueado ? ' ⚠' : '' ?>
          </option>
        <?php endforeach; ?>
      </select>
      <div class="reglas p-3 mt-3 small" id="infoSocio">Selecciona un socio para ver su situación.</div>
    </div></div>
  </div>
  <div class="col-lg-6">
    <div class="card h-100"><div class="card-body">
      <h2 class="h6">2. Ejemplar disponible</h2>
      <input class="form-control mb-2" type="search" placeholder="Buscar por título, ISBN o código" data-buscar="#selEjemplar" aria-label="Buscar ejemplar">
      <select class="form-select" id="selEjemplar" name="id_ejemplar" size="10" required>
        <?php foreach ($ejemplares as $ej): ?>
          <option value="<?= $ej['id_ejemplar'] ?>"><?= e($ej['codigo_inventario'] . ' · ' . $ej['titulo'] . ' · ' . $ej['isbn'] . ' · ' . $ej['ubicacion']) ?></option>
        <?php endforeach; ?>
      </select>
      <p class="small text-body-secondary mt-2 mb-0"><?= count($ejemplares) ?> ejemplar(es) disponibles para préstamo.</p>
    </div></div>
  </div>
  <div class="col-12 d-flex justify-content-end gap-2">
    <a class="btn btn-light" href="prestamos.php">Cancelar</a>
    <button class="btn btn-primario btn-lg"><i class="bi bi-check2-circle"></i> Registrar préstamo</button>
  </div>
</form>

<?php
$scripts_extra = <<<'JS'
<script>
// Filtra las opciones de un <select> mientras se escribe
document.querySelectorAll('[data-buscar]').forEach((input) => {
  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    document.querySelectorAll(input.dataset.buscar + ' option').forEach((o) => { o.hidden = q !== '' && !o.textContent.toLowerCase().includes(q); });
  });
});
// Muestra la situación del socio seleccionado
const pesos = (n) => '$' + Number(n).toFixed(2);
document.getElementById('selSocio').addEventListener('change', (e) => {
  const s = JSON.parse(e.target.selectedOptions[0].dataset.info);
  const avisos = [];
  if (Number(s.vencidos) > 0) avisos.push('Tiene ' + s.vencidos + ' préstamo(s) vencido(s).');
  if (Number(s.adeudo) > 0) avisos.push('Debe ' + pesos(s.adeudo) + ' en multas.');
  if (Number(s.activos) >= Number(s.max_prestamos)) avisos.push('Ya alcanzó su máximo de préstamos.');
  document.getElementById('infoSocio').innerHTML =
    '<strong>' + s.tipo + '</strong>: préstamos ' + s.activos + ' de ' + s.max_prestamos + ' · plazo ' + s.dias_prestamo + ' días' +
    (avisos.length ? '<div class="text-danger mt-1">⚠ ' + avisos.join(' ') + '</div>' : '<div class="text-success mt-1">✔ Puede llevarse un libro.</div>');
});
</script>
JS;
require __DIR__ . '/includes/footer.php'; ?>
