<?php
require_once __DIR__ . '/includes/funciones.php';

$meses = (int)($_GET['meses'] ?? 6);
if (!in_array($meses, [1, 3, 6, 12], true)) $meses = 6;

// 1) Préstamos por mes
$stmt = db()->prepare("SELECT DATE_FORMAT(fecha_prestamo, '%Y-%m') AS mes, COUNT(*) AS total
                       FROM prestamos WHERE fecha_prestamo >= CURDATE() - INTERVAL ? MONTH
                       GROUP BY mes ORDER BY mes");
$stmt->execute([$meses]);
$porMes = $stmt->fetchAll();

// 2) Top 5 libros más prestados 
$stmt = db()->prepare('SELECT l.titulo, COUNT(*) AS prestamos
                       FROM prestamos p
                       JOIN ejemplares e ON e.id_ejemplar = p.id_ejemplar
                       JOIN libros l     ON l.id_libro    = e.id_libro
                       WHERE p.fecha_prestamo >= CURDATE() - INTERVAL ? MONTH
                       GROUP BY l.id_libro, l.titulo
                       ORDER BY prestamos DESC, l.titulo LIMIT 5');
$stmt->execute([$meses]);
$top = $stmt->fetchAll();

// 3) Préstamos por categoría 
$stmt = db()->prepare('SELECT c.nombre AS categoria, COUNT(*) AS prestamos, COUNT(DISTINCT p.id_socio) AS lectores
                       FROM prestamos p
                       JOIN ejemplares e ON e.id_ejemplar  = p.id_ejemplar
                       JOIN libros l     ON l.id_libro     = e.id_libro
                       JOIN categorias c ON c.id_categoria = l.id_categoria
                       WHERE p.fecha_prestamo >= CURDATE() - INTERVAL ? MONTH
                       GROUP BY c.id_categoria, c.nombre ORDER BY prestamos DESC');
$stmt->execute([$meses]);
$porCategoria = $stmt->fetchAll();

// 4) Socios que leen más que el promedio
$lectores = db()->query(
    'SELECT CONCAT(s.nombre, " ", s.apellidos) AS socio, t.nombre AS tipo, COUNT(*) AS prestamos
     FROM prestamos p JOIN socios s ON s.id_socio = p.id_socio JOIN tipos_socio t ON t.id_tipo = s.id_tipo
     GROUP BY s.id_socio, s.nombre, s.apellidos, t.nombre
     HAVING COUNT(*) > (SELECT AVG(x.n) FROM (SELECT COUNT(*) AS n FROM prestamos GROUP BY id_socio) AS x)
     ORDER BY prestamos DESC'
)->fetchAll();

// 5) Libros nunca prestados (NOT EXISTS)
$nunca = db()->query(
    'SELECT l.titulo, l.isbn FROM libros l
     WHERE NOT EXISTS (SELECT 1 FROM ejemplares e JOIN prestamos p ON p.id_ejemplar = e.id_ejemplar WHERE e.id_libro = l.id_libro)
     ORDER BY l.titulo'
)->fetchAll();

// 6) Puntualidad por tipo de socio
$puntualidad = db()->query(
    "SELECT t.nombre AS tipo, COUNT(*) AS devueltos,
            SUM(DATE(p.fecha_devolucion) <= p.fecha_limite) AS a_tiempo,
            ROUND(100 * SUM(DATE(p.fecha_devolucion) <= p.fecha_limite) / COUNT(*), 1) AS porcentaje,
            SUM(p.multa) AS multas
     FROM prestamos p JOIN socios s ON s.id_socio = p.id_socio JOIN tipos_socio t ON t.id_tipo = s.id_tipo
     WHERE p.fecha_devolucion IS NOT NULL
     GROUP BY t.id_tipo, t.nombre ORDER BY porcentaje DESC"
)->fetchAll();

$graficas = [
    'meses' => array_column($porMes, 'mes'), 'totales' => array_map('intval', array_column($porMes, 'total')),
    'categorias' => array_column($porCategoria, 'categoria'), 'porCategoria' => array_map('intval', array_column($porCategoria, 'prestamos')),
];

$titulo = 'Reportes';
$scripts_extra = '<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>'
    . '<script>window.GRAFICAS = ' . json_encode($graficas, JSON_HEX_TAG) . ';</script><script src="assets/js/reportes.js"></script>';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-bar-chart"></i> Reportes</h1>
  <form method="get" class="d-flex gap-2 align-items-center">
    <label for="meses" class="small text-body-secondary text-nowrap">Periodo</label>
    <select class="form-select" id="meses" name="meses" onchange="this.form.submit()">
      <?php foreach ([1 => 'Último mes', 3 => 'Últimos 3 meses', 6 => 'Últimos 6 meses', 12 => 'Último año'] as $v => $t): ?><option value="<?= $v ?>" <?= $meses === $v ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?>
    </select>
  </form>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-7"><div class="card h-100"><div class="card-body"><h2 class="h6">Préstamos por mes</h2><canvas id="graficaMes" height="130" aria-label="Préstamos por mes"></canvas></div></div></div>
  <div class="col-lg-5"><div class="card h-100"><div class="card-body"><h2 class="h6">Préstamos por categoría</h2><canvas id="graficaCategoria" height="200" aria-label="Préstamos por categoría"></canvas></div></div></div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-6"><div class="card h-100">
    <div class="card-header bg-white fw-semibold">Top 5 libros más prestados</div>
    <table class="table mb-0"><thead class="table-light"><tr><th>Libro</th><th class="text-center">Préstamos</th></tr></thead><tbody>
      <?php foreach ($top as $t): ?><tr><td><?= e($t['titulo']) ?></td><td class="text-center"><?= (int)$t['prestamos'] ?></td></tr><?php endforeach; ?>
      <?php if (!$top): ?><tr><td colspan="2" class="text-center text-body-secondary">Sin datos</td></tr><?php endif; ?>
    </tbody></table>
  </div></div>
  <div class="col-lg-6"><div class="card h-100">
    <div class="card-header bg-white fw-semibold">Puntualidad por tipo de socio</div>
    <table class="table mb-0"><thead class="table-light"><tr><th>Tipo</th><th class="text-center">Devueltos</th><th class="text-center">A tiempo</th><th class="text-end">Multas</th></tr></thead><tbody>
      <?php foreach ($puntualidad as $p): ?><tr><td><?= e($p['tipo']) ?></td><td class="text-center"><?= (int)$p['devueltos'] ?></td><td class="text-center"><?= e((string)$p['porcentaje']) ?>%</td><td class="text-end"><?= dinero($p['multas']) ?></td></tr><?php endforeach; ?>
    </tbody></table>
  </div></div>
</div>

<div class="row g-3">
  <div class="col-lg-6"><div class="card h-100">
    <div class="card-header bg-white fw-semibold">Socios que leen más que el promedio <span class="badge text-bg-light">HAVING + subconsulta</span></div>
    <ul class="list-group list-group-flush">
      <?php foreach ($lectores as $l): ?><li class="list-group-item d-flex justify-content-between"><span><?= e($l['socio']) ?> <small class="text-body-secondary">(<?= e($l['tipo']) ?>)</small></span><strong><?= (int)$l['prestamos'] ?></strong></li><?php endforeach; ?>
    </ul>
  </div></div>
  <div class="col-lg-6"><div class="card h-100">
    <div class="card-header bg-white fw-semibold">Libros nunca prestados <span class="badge text-bg-light">NOT EXISTS</span></div>
    <ul class="list-group list-group-flush">
      <?php foreach ($nunca as $n): ?><li class="list-group-item d-flex justify-content-between"><span><?= e($n['titulo']) ?></span><span class="small font-monospace text-body-secondary"><?= e($n['isbn']) ?></span></li><?php endforeach; ?>
      <?php if (!$nunca): ?><li class="list-group-item text-center text-body-secondary">Todos los libros se han prestado al menos una vez.</li><?php endif; ?>
    </ul>
  </div></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
