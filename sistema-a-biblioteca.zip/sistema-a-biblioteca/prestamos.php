<?php
/**
 * Préstamos: listado con filtros, devolución (transacción que calcula la multa)
 * y pago de multas.
 */
require_once __DIR__ . '/includes/funciones.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verificar_csrf();
    $id  = (int)($_POST['id'] ?? 0);
    $pdo = db();
    try {
        if (($_POST['accion'] ?? '') === 'devolver') {
            $pdo->beginTransaction();
            // Bloquea el préstamo y obtiene la tarifa de multa del tipo de socio
            $stmt = $pdo->prepare(
                'SELECT p.fecha_limite, p.fecha_devolucion, t.multa_diaria
                 FROM prestamos p
                 JOIN socios s ON s.id_socio = p.id_socio
                 JOIN tipos_socio t ON t.id_tipo = s.id_tipo
                 WHERE p.id_prestamo = ? FOR UPDATE'
            );
            $stmt->execute([$id]);
            $p = $stmt->fetch();
            if (!$p)                    throw new InvalidArgumentException('El préstamo no existe.');
            if ($p['fecha_devolucion']) throw new InvalidArgumentException('El préstamo ya estaba devuelto.');

            $dias  = max(0, (int)((strtotime(date('Y-m-d')) - strtotime($p['fecha_limite'])) / 86400));
            $multa = round($dias * (float)$p['multa_diaria'], 2);

            $pdo->prepare('UPDATE prestamos SET fecha_devolucion = NOW(), multa = ? WHERE id_prestamo = ?')->execute([$multa, $id]);
            $pdo->commit();
            flash($multa > 0 ? 'warning' : 'success', $multa > 0 ? "Devolución registrada con $dias día(s) de retraso. Multa: " . dinero($multa) . '.' : 'Devolución registrada a tiempo, sin multa.');
        } elseif (($_POST['accion'] ?? '') === 'pagar') {
            $stmt = db()->prepare('UPDATE prestamos SET multa_pagada = 1 WHERE id_prestamo = ? AND multa > 0 AND multa_pagada = 0');
            $stmt->execute([$id]);
            flash($stmt->rowCount() ? 'success' : 'warning', $stmt->rowCount() ? 'Multa marcada como pagada.' : 'No había multa pendiente en ese préstamo.');
        }
    } catch (InvalidArgumentException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('warning', $e->getMessage());
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('danger', mensaje_error_bd($e));
    }
    redirigir('prestamos.php?' . http_build_query(array_filter(['estado' => $_GET['estado'] ?? '', 'q' => $_GET['q'] ?? ''])));
}

$estado = $_GET['estado'] ?? 'abiertos';
$q      = trim($_GET['q'] ?? '');

$sql = 'SELECT * FROM v_prestamos WHERE 1 = 1';
$p = [];
if ($estado === 'abiertos')                                          { $sql .= " AND estado IN ('Activo','Vencido')"; }
elseif (in_array($estado, ['Activo', 'Vencido', 'Devuelto'], true)) { $sql .= ' AND estado = ?'; $p[] = $estado; }
elseif ($estado === 'multas')                                        { $sql .= ' AND multa > 0 AND multa_pagada = 0'; }
if ($q !== '') { $sql .= ' AND (socio LIKE ? OR matricula LIKE ? OR titulo LIKE ? OR codigo_inventario LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
$sql .= " ORDER BY FIELD(estado, 'Vencido', 'Activo', 'Devuelto'), fecha_limite, id_prestamo DESC";
$stmt = db()->prepare($sql);
$stmt->execute($p);
$prestamos = $stmt->fetchAll();

$titulo = 'Préstamos';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h1 class="h3 mb-0"><i class="bi bi-arrow-left-right"></i> Préstamos</h1>
  <a class="btn btn-primario" href="prestamo_nuevo.php"><i class="bi bi-journal-plus"></i> Nuevo préstamo</a>
</div>

<form class="row g-2 mb-3" method="get">
  <div class="col-md-4">
    <select class="form-select" name="estado" onchange="this.form.submit()" aria-label="Estado">
      <?php foreach (['abiertos' => 'Sin devolver (activos y vencidos)', 'Vencido' => 'Solo vencidos', 'Activo' => 'Solo activos', 'Devuelto' => 'Devueltos', 'multas' => 'Con multa pendiente', 'todos' => 'Todos'] as $v => $t): ?>
        <option value="<?= $v ?>" <?= $estado === $v ? 'selected' : '' ?>><?= $t ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="col-md-6"><input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="Buscar por socio, matrícula, título o código" aria-label="Buscar"></div>
  <div class="col-md-2 d-grid"><button class="btn btn-outline-secondary"><i class="bi bi-search"></i> Buscar</button></div>
</form>

<div class="card">
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead class="table-light"><tr><th>#</th><th>Libro</th><th>Socio</th><th>Préstamo</th><th>Límite</th><th class="text-center">Estado</th><th class="text-end">Multa</th><th class="text-end">Acciones</th></tr></thead>
      <tbody>
      <?php foreach ($prestamos as $pr): ?>
        <tr>
          <td><?= (int)$pr['id_prestamo'] ?></td>
          <td><span class="fw-semibold"><?= e($pr['titulo']) ?></span><div class="small text-body-secondary font-monospace"><?= e($pr['codigo_inventario']) ?></div></td>
          <td><?= e($pr['socio']) ?><div class="small text-body-secondary"><?= e($pr['matricula']) ?> · <?= e($pr['tipo_socio']) ?></div></td>
          <td class="text-nowrap"><?= fecha($pr['fecha_prestamo']) ?></td>
          <td class="text-nowrap"><?= fecha($pr['fecha_limite']) ?><?php if ($pr['estado'] === 'Vencido'): ?><div class="small text-danger"><?= (int)$pr['dias_retraso'] ?> día(s) de retraso</div><?php elseif ($pr['fecha_devolucion']): ?><div class="small text-body-secondary">Devuelto <?= fecha($pr['fecha_devolucion']) ?></div><?php endif; ?></td>
          <td class="text-center"><?= badge_estado($pr['estado']) ?></td>
          <td class="text-end"><?php if ($pr['multa_calculada'] > 0): ?><span class="<?= $pr['multa_pagada'] ? 'text-success' : 'text-danger fw-semibold' ?>"><?= dinero($pr['multa_calculada']) ?></span><div class="small text-body-secondary"><?= $pr['fecha_devolucion'] ? ($pr['multa_pagada'] ? 'Pagada' : 'Pendiente') : 'Estimada' ?></div><?php else: ?><span class="text-body-secondary">—</span><?php endif; ?></td>
          <td class="text-end text-nowrap">
            <?php if (!$pr['fecha_devolucion']): ?>
              <form method="post" class="d-inline" data-confirmar="¿Registrar la devolución de «<?= e($pr['titulo']) ?>»?">
                <?= csrf_campo() ?><input type="hidden" name="accion" value="devolver"><input type="hidden" name="id" value="<?= (int)$pr['id_prestamo'] ?>">
                <button class="btn btn-sm btn-success"><i class="bi bi-box-arrow-in-left"></i> Devolver</button>
              </form>
            <?php elseif ($pr['multa'] > 0 && !$pr['multa_pagada']): ?>
              <form method="post" class="d-inline" data-confirmar="¿Marcar como pagada la multa de <?= dinero($pr['multa']) ?>?">
                <?= csrf_campo() ?><input type="hidden" name="accion" value="pagar"><input type="hidden" name="id" value="<?= (int)$pr['id_prestamo'] ?>">
                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-cash"></i> Pagar multa</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$prestamos): ?><tr><td colspan="8" class="text-center text-body-secondary py-4">No hay préstamos con ese filtro.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer bg-white small text-body-secondary"><?= count($prestamos) ?> préstamo(s)</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
