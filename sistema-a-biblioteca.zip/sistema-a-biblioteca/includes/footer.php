</main>

<footer class="text-center text-body-secondary small py-3 border-top">
  Sistema  Biblioteca 
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
<?php if (!empty($scripts_extra)) echo $scripts_extra; ?>
</body>
</html>
