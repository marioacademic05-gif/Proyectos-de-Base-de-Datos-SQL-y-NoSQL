<?php
/**
 * Funciones de apoyo usadas en todas las páginas.
 */

require_once __DIR__ . '/../config/db.php';

date_default_timezone_set('America/Mexico_City');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Escapa texto para HTML (evita XSS). */
function e(?string $texto): string
{
    return htmlspecialchars($texto ?? '', ENT_QUOTES, 'UTF-8');
}

function dinero($cantidad): string
{
    return '$' . number_format((float)$cantidad, 2);
}

function fecha(?string $f, bool $hora = false): string
{
    return $f ? date($hora ? 'd/m/Y H:i' : 'd/m/Y', strtotime($f)) : '';
}

/** Mensajes después de redirigir (patrón PRG). */
function flash(string $tipo, string $mensaje): void
{
    $_SESSION['flash'][] = ['tipo' => $tipo, 'mensaje' => $mensaje];
}

function obtener_flash(): array
{
    $m = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $m;
}

function redirigir(string $url): never
{
    header('Location: ' . $url);
    exit;
}

/** Token CSRF */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_campo(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function verificar_csrf(): void
{
    if (!hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419);
        exit('Token de seguridad inválido. Recarga la página e intenta de nuevo.');
    }
}

function post_texto(string $campo): string
{
    return trim((string)($_POST[$campo] ?? ''));
}

function vacio_a_null(string $t): ?string
{
    return $t === '' ? null : $t;
}

/**
 * Traduce los errores de MySQL más comunes.
 */
function mensaje_error_bd(PDOException $e): string
{
    return match ($e->errorInfo[1] ?? 0) {
        1062    => str_contains($e->getMessage(), 'uq_prestamo_abierto')
                    ? 'Ese ejemplar ya tiene un préstamo abierto.'
                    : 'Ya existe un registro con ese valor (dato duplicado).',
        1451    => 'No se puede eliminar porque tiene registros relacionados (ejemplares, préstamos o libros).',
        1452    => 'El registro relacionado no existe.',
        3819    => 'Los datos no cumplen una regla de la base de datos (revisa fechas, año o ISBN).',
        default => 'Error en la base de datos: ' . $e->getMessage(),
    };
}

function menu_activo(string ...$paginas): string
{
    return in_array(basename($_SERVER['SCRIPT_NAME']), $paginas, true) ? 'active' : '';
}

/** Badge de color según el estado de un préstamo o ejemplar. */
function badge_estado(string $estado): string
{
    $color = match ($estado) {
        'Activo', 'Disponible' => 'success',
        'Vencido', 'Baja'      => 'danger',
        'Prestado'             => 'warning',
        'Mantenimiento'        => 'secondary',
        default                => 'light',
    };
    return '<span class="badge text-bg-' . $color . '">' . e($estado) . '</span>';
}
