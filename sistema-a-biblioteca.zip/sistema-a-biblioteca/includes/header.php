<?php
/** Encabezado y menú comunes. Antes de incluirlo se define $titulo. */
$titulo = $titulo ?? 'Biblioteca';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($titulo) ?>  Biblioteca</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="assets/css/app.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark barra sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand fw-semibold" href="index.php"><i class="bi bi-book-half"></i> Biblioteca</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu"
            aria-controls="menu" aria-expanded="false" aria-label="Abrir menú">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="menu">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link <?= menu_activo('index.php') ?>" href="index.php"><i class="bi bi-speedometer2"></i> Inicio</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('prestamo_nuevo.php') ?>" href="prestamo_nuevo.php"><i class="bi bi-journal-plus"></i> Nuevo préstamo</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('prestamos.php') ?>" href="prestamos.php"><i class="bi bi-arrow-left-right"></i> Préstamos</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('libros.php', 'libro_detalle.php') ?>" href="libros.php"><i class="bi bi-book"></i> Libros</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('socios.php') ?>" href="socios.php"><i class="bi bi-person-vcard"></i> Socios</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('autores.php') ?>" href="autores.php"><i class="bi bi-pen"></i> Autores</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('categorias.php') ?>" href="categorias.php"><i class="bi bi-tags"></i> Categorías</a></li>
        <li class="nav-item"><a class="nav-link <?= menu_activo('reportes.php') ?>" href="reportes.php"><i class="bi bi-bar-chart"></i> Reportes</a></li>
      </ul>
    </div>
  </div>
</nav>

<main class="container-xl py-4">
  <?php foreach (obtener_flash() as $f): ?>
    <div class="alert alert-<?= e($f['tipo']) ?> alert-dismissible fade show" role="alert">
      <?= e($f['mensaje']) ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
    </div>
  <?php endforeach; ?>
