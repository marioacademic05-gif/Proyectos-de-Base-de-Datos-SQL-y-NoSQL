<?php
/**
 * Tablero: indicadores, préstamos vencidos y los que vencen pronto.
 */
require_once __DIR__ . '/includes/funciones.php';

$k = db()->query(
    "SELECT (SELECT COUNT(*) FROM libros) AS libros,
            (SELECT COUNT(*) FROM ejemplares WHERE estado <> 'Baja') AS ejemplares,
            (SELECT COUNT(*) FROM v_ejemplares WHERE disponibilidad = 'Disponible') AS disponibles,
            (SELECT COUNT(*) FROM socios WHERE activo = 1) AS socios,
            (SELECT COUNT(*) FROM prestamos WHERE fecha_devolucion IS NULL) AS activos,
            (SELECT COUNT(*) FROM prestamos WHERE fecha_devolucion IS NULL AND CURDATE() > fecha_limite) AS vencidos,
            (SELECT COALESCE(SUM(multa), 0) FROM prestamos WHERE multa > 0 AND multa_pagada = 0) AS multas"
)->fetch();

$vencidos = db()->query("SELECT * FROM v_prestamos WHERE estado = 'Vencido' ORDER BY fecha_limite")->fetchAll();
$porVencer = db()->query(
    "SELECT * FROM v_prestamos WHERE estado = 'Activo' AND fecha_limite <= CURDATE() + INTERVAL 3 DAY ORDER BY fecha_limite"
)->fetchAll();
$recientes = db()->query('SELECT * FROM v_prestamos ORDER BY GREATEST(fecha_prestamo, COALESCE(fecha_devolucion, fecha_prestamo)) DESC LIMIT 6')->fetchAll();

$titulo = 'Inicio';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
  <h1 class="h3 mb-0">Tablero</h1>
  <a class="btn btn-primario btn-lg" href="prestamo_nuevo.php"><i class="bi bi-journal-plus"></i> Nuevo préstamo</a>
</div>

<div class="row g-3 mb-4">
  <?php foreach ([
      ['Préstamos activos', $k['activos'], 'bi-arrow-left-right', 'primary'],
      ['Vencidos', $k['vencidos'], 'bi-exclamation-octagon', 'danger'],
      ['Ejemplares disponibles', $k['disponibles'] . ' / ' . $k['ejemplares'], 'bi-book', 'success'],
      ['Multas por cobrar', dinero($k['multas']), 'bi-cash-coin', 'warning'],
  ] as [$t, $v, $i, $c]): ?>
    <div class="col-6 col-lg-3">
      <div class="card kpi h-100"><div class="card-body d-flex align-items-center gap-3">
        <div class="icono bg-<?= $c ?>-subtle text-<?= $c ?>"><i class="bi <?= $i ?>"></i></div>
        <div><div class="text-body-secondary small"><?= $t ?></div><div class="valor"><?= e((string)$v) ?></div></div>
      </div></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card h-100">
      <div class="card-header bg-white fw-semibold"><i class="bi bi-exclamation-octagon text-danger"></i> Préstamos vencidos</div>
      <ul class="list-group list-group-flush">
        <?php foreach ($vencidos as $v): ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <span><?= e($v['titulo']) ?><br><small class="text-body-secondary"><?= e($v['socio']) ?> · venció <?= fecha($v['fecha_limite']) ?></small></span>
            <span class="text-end"><span class="badge text-bg-danger"><?= (int)$v['dias_retraso'] ?> días</span><br><small class="text-danger"><?= dinero($v['multa_calculada']) ?></small></span>
          </li>
        <?php endforeach; ?>
        <?php if (!$vencidos): ?><li class="list-group-item text-center text-body-secondary py-4">No hay préstamos vencidos.</li><?php endif; ?>
      </ul>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card mb-3">
      <div class="card-header bg-white fw-semibold"><i class="bi bi-clock-history text-warning"></i> Vencen en los próximos 3 días</div>
      <ul class="list-group list-group-flush">
        <?php foreach ($porVencer as $v): ?>
          <li class="list-group-item d-flex justify-content-between"><span><?= e($v['titulo']) ?> <small class="text-body-secondary">· <?= e($v['socio']) ?></small></span><span class="small"><?= fecha($v['fecha_limite']) ?></span></li>
        <?php endforeach; ?>
        <?php if (!$porVencer): ?><li class="list-group-item text-center text-body-secondary">Ninguno.</li><?php endif; ?>
      </ul>
    </div>
    <div class="card">
      <div class="card-header bg-white fw-semibold d-flex justify-content-between">Movimientos recientes <a class="small" href="prestamos.php?estado=todos">Ver todos</a></div>
      <ul class="list-group list-group-flush">
        <?php foreach ($recientes as $r): ?>
          <li class="list-group-item d-flex justify-content-between align-items-center"><span class="small"><?= e($r['titulo']) ?> · <?= e($r['socio']) ?></span><?= badge_estado($r['estado']) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
