-- =====================================================================
--  SISTEMA A - BIBLIOTECA
--  Script 03: consultas relevantes (evidencias para la documentación)
-- =====================================================================
USE biblioteca;
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 1) JOIN de 4 tablas: libros con sus autores (relación N:M) y categoría
SELECT l.titulo, c.nombre AS categoria,
       GROUP_CONCAT(CONCAT(a.nombre, ' ', a.apellidos) ORDER BY a.apellidos SEPARATOR ', ') AS autores
FROM libros l
JOIN categorias  c  ON c.id_categoria = l.id_categoria
JOIN libro_autor la ON la.id_libro    = l.id_libro
JOIN autores     a  ON a.id_autor     = la.id_autor
GROUP BY l.id_libro, l.titulo, c.nombre
ORDER BY l.titulo;

-- 2) Préstamos vencidos con días de retraso y multa estimada (vista)
SELECT id_prestamo, titulo, socio, fecha_limite, dias_retraso, multa_calculada
FROM v_prestamos
WHERE estado = 'Vencido'
ORDER BY dias_retraso DESC;

-- 3) GROUP BY + ORDER BY + LIMIT: 5 libros más prestados
SELECT l.titulo, COUNT(*) AS prestamos
FROM prestamos p
JOIN ejemplares e ON e.id_ejemplar = p.id_ejemplar
JOIN libros     l ON l.id_libro    = e.id_libro
GROUP BY l.id_libro, l.titulo
ORDER BY prestamos DESC, l.titulo
LIMIT 5;

-- 4) Préstamos por categoría y lectores distintos
SELECT c.nombre AS categoria, COUNT(*) AS prestamos, COUNT(DISTINCT p.id_socio) AS lectores
FROM prestamos p
JOIN ejemplares e ON e.id_ejemplar  = p.id_ejemplar
JOIN libros     l ON l.id_libro     = e.id_libro
JOIN categorias c ON c.id_categoria = l.id_categoria
GROUP BY c.id_categoria, c.nombre
ORDER BY prestamos DESC;

-- 5) HAVING + subconsulta: socios con más préstamos que el promedio
SELECT CONCAT(s.nombre, ' ', s.apellidos) AS socio, COUNT(*) AS prestamos
FROM prestamos p
JOIN socios s ON s.id_socio = p.id_socio
GROUP BY s.id_socio, s.nombre, s.apellidos
HAVING COUNT(*) > (SELECT AVG(x.n) FROM (SELECT COUNT(*) AS n FROM prestamos GROUP BY id_socio) AS x)
ORDER BY prestamos DESC;

-- 6) Subconsulta correlacionada: socios con multas pendientes
SELECT s.matricula, CONCAT(s.nombre, ' ', s.apellidos) AS socio,
       (SELECT SUM(p.multa) FROM prestamos p
         WHERE p.id_socio = s.id_socio AND p.multa > 0 AND p.multa_pagada = 0) AS adeudo
FROM socios s
WHERE EXISTS (SELECT 1 FROM prestamos p WHERE p.id_socio = s.id_socio AND p.multa > 0 AND p.multa_pagada = 0)
ORDER BY adeudo DESC;

-- 7) NOT EXISTS: libros que nunca se han prestado
SELECT l.titulo, l.isbn
FROM libros l
WHERE NOT EXISTS (SELECT 1 FROM ejemplares e JOIN prestamos p ON p.id_ejemplar = e.id_ejemplar
                  WHERE e.id_libro = l.id_libro);

-- 8) Disponibilidad de ejemplares (vista calculada)
SELECT disponibilidad, COUNT(*) AS ejemplares FROM v_ejemplares GROUP BY disponibilidad;

-- 9) Puntualidad por tipo de socio
SELECT t.nombre AS tipo, COUNT(*) AS devueltos,
       ROUND(100 * SUM(DATE(p.fecha_devolucion) <= p.fecha_limite) / COUNT(*), 1) AS pct_a_tiempo,
       SUM(p.multa) AS multas
FROM prestamos p
JOIN socios s ON s.id_socio = p.id_socio
JOIN tipos_socio t ON t.id_tipo = s.id_tipo
WHERE p.fecha_devolucion IS NOT NULL
GROUP BY t.id_tipo, t.nombre;

-- 10) Plan de ejecución: los préstamos vencidos usan el índice idx_prestamos_limite
EXPLAIN SELECT id_prestamo FROM prestamos WHERE fecha_limite < CURDATE() - INTERVAL 30 DAY\G
