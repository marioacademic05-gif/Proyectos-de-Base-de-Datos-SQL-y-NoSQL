-- =====================================================================
--  SISTEMA A - BIBLIOTECA (BD RELACIONAL)
--  Script 01: base de datos, tablas, restricciones, índices y vistas
--  Motor: MySQL 8.x (Laragon) · Normalización: 3FN
-- =====================================================================

-- Misma collation en la sesión que en la BD (los textos de las vistas la heredan)
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

DROP DATABASE IF EXISTS biblioteca;
CREATE DATABASE biblioteca CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE biblioteca;

-- ---------------------------------------------------------------------
-- CATEGORIAS de libros
-- ---------------------------------------------------------------------
CREATE TABLE categorias (
  id_categoria  INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(60)  NOT NULL,
  CONSTRAINT pk_categorias PRIMARY KEY (id_categoria),
  CONSTRAINT uq_categorias_nombre UNIQUE (nombre)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- AUTORES
-- ---------------------------------------------------------------------
CREATE TABLE autores (
  id_autor      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(60)  NOT NULL,
  apellidos     VARCHAR(80)  NOT NULL,
  nacionalidad  VARCHAR(40)  NULL,
  CONSTRAINT pk_autores PRIMARY KEY (id_autor)
) ENGINE = InnoDB;

CREATE INDEX idx_autores_apellidos ON autores (apellidos, nombre);

-- ---------------------------------------------------------------------
-- LIBROS (la obra: título, ISBN...). Las copias físicas van en EJEMPLARES.
-- ---------------------------------------------------------------------
CREATE TABLE libros (
  id_libro          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  isbn              VARCHAR(17)   NOT NULL,
  titulo            VARCHAR(150)  NOT NULL,
  id_categoria      INT UNSIGNED  NOT NULL,
  editorial         VARCHAR(80)   NULL,
  anio_publicacion  SMALLINT      NULL,
  creado_en         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_libros PRIMARY KEY (id_libro),
  CONSTRAINT uq_libros_isbn UNIQUE (isbn),
  CONSTRAINT fk_libros_categoria FOREIGN KEY (id_categoria)
    REFERENCES categorias (id_categoria) ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT ck_libros_anio CHECK (anio_publicacion IS NULL OR anio_publicacion BETWEEN 1450 AND 2100),
  CONSTRAINT ck_libros_isbn CHECK (CHAR_LENGTH(REPLACE(isbn, '-', '')) IN (10, 13))
) ENGINE = InnoDB;

CREATE INDEX idx_libros_titulo ON libros (titulo);

-- ---------------------------------------------------------------------
-- LIBRO_AUTOR: relación N:M (un libro puede tener varios autores)
-- ---------------------------------------------------------------------
CREATE TABLE libro_autor (
  id_libro  INT UNSIGNED NOT NULL,
  id_autor  INT UNSIGNED NOT NULL,
  CONSTRAINT pk_libro_autor PRIMARY KEY (id_libro, id_autor),
  CONSTRAINT fk_la_libro FOREIGN KEY (id_libro) REFERENCES libros (id_libro)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_la_autor FOREIGN KEY (id_autor) REFERENCES autores (id_autor)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- EJEMPLARES: cada copia física de un libro.
-- El estado "Prestado" NO se guarda: se deduce de PRESTAMOS (evita
-- redundancia y contradicciones). Aquí solo el estado físico.
-- ---------------------------------------------------------------------
CREATE TABLE ejemplares (
  id_ejemplar        INT UNSIGNED NOT NULL AUTO_INCREMENT,
  id_libro           INT UNSIGNED NOT NULL,
  codigo_inventario  VARCHAR(20)  NOT NULL,
  ubicacion          VARCHAR(30)  NULL,
  estado             ENUM('Disponible','Mantenimiento','Baja') NOT NULL DEFAULT 'Disponible',
  CONSTRAINT pk_ejemplares PRIMARY KEY (id_ejemplar),
  CONSTRAINT uq_ejemplares_codigo UNIQUE (codigo_inventario),
  CONSTRAINT fk_ejemplares_libro FOREIGN KEY (id_libro) REFERENCES libros (id_libro)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- TIPOS_SOCIO: las reglas dependen del tipo, no del socio (3FN)
-- ---------------------------------------------------------------------
CREATE TABLE tipos_socio (
  id_tipo         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  nombre          VARCHAR(30)   NOT NULL,
  max_prestamos   TINYINT       NOT NULL,
  dias_prestamo   TINYINT       NOT NULL,
  multa_diaria    DECIMAL(6,2)  NOT NULL,
  CONSTRAINT pk_tipos_socio PRIMARY KEY (id_tipo),
  CONSTRAINT uq_tipos_nombre UNIQUE (nombre),
  CONSTRAINT ck_tipos_max   CHECK (max_prestamos BETWEEN 1 AND 20),
  CONSTRAINT ck_tipos_dias  CHECK (dias_prestamo BETWEEN 1 AND 60),
  CONSTRAINT ck_tipos_multa CHECK (multa_diaria >= 0)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- SOCIOS (usuarios de la biblioteca)
-- ---------------------------------------------------------------------
CREATE TABLE socios (
  id_socio    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  matricula   VARCHAR(15)  NOT NULL,
  nombre      VARCHAR(60)  NOT NULL,
  apellidos   VARCHAR(80)  NOT NULL,
  email       VARCHAR(120) NULL,
  telefono    VARCHAR(15)  NULL,
  id_tipo     INT UNSIGNED NOT NULL,
  activo      TINYINT(1)   NOT NULL DEFAULT 1,
  creado_en   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT pk_socios PRIMARY KEY (id_socio),
  CONSTRAINT uq_socios_matricula UNIQUE (matricula),
  CONSTRAINT uq_socios_email UNIQUE (email),
  CONSTRAINT fk_socios_tipo FOREIGN KEY (id_tipo) REFERENCES tipos_socio (id_tipo)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE = InnoDB;

CREATE INDEX idx_socios_apellidos ON socios (apellidos, nombre);

-- ---------------------------------------------------------------------
-- PRESTAMOS
-- multa: se guarda al devolver porque es un hecho histórico (la tarifa
-- puede cambiar después). prestamo_abierto es una columna generada que
-- vale 1 mientras no se devuelve y NULL después; con el índice UNIQUE
-- (id_ejemplar, prestamo_abierto) MySQL impide dos préstamos abiertos
-- del mismo ejemplar (los NULL no chocan entre sí).
-- ---------------------------------------------------------------------
CREATE TABLE prestamos (
  id_prestamo       INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  id_ejemplar       INT UNSIGNED  NOT NULL,
  id_socio          INT UNSIGNED  NOT NULL,
  fecha_prestamo    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_limite      DATE          NOT NULL,
  fecha_devolucion  DATETIME      NULL,
  multa             DECIMAL(8,2)  NOT NULL DEFAULT 0,
  multa_pagada      TINYINT(1)    NOT NULL DEFAULT 0,
  prestamo_abierto  TINYINT GENERATED ALWAYS AS (IF(fecha_devolucion IS NULL, 1, NULL)) STORED,
  CONSTRAINT pk_prestamos PRIMARY KEY (id_prestamo),
  CONSTRAINT fk_prestamos_ejemplar FOREIGN KEY (id_ejemplar) REFERENCES ejemplares (id_ejemplar)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_prestamos_socio FOREIGN KEY (id_socio) REFERENCES socios (id_socio)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT uq_prestamo_abierto UNIQUE (id_ejemplar, prestamo_abierto),
  CONSTRAINT ck_prestamos_limite CHECK (fecha_limite >= CAST(fecha_prestamo AS DATE)),
  CONSTRAINT ck_prestamos_devolucion CHECK (fecha_devolucion IS NULL OR fecha_devolucion >= fecha_prestamo),
  CONSTRAINT ck_prestamos_multa CHECK (multa >= 0)
) ENGINE = InnoDB;

-- Para listar préstamos vencidos y reportes por fecha
CREATE INDEX idx_prestamos_limite ON prestamos (fecha_limite);
CREATE INDEX idx_prestamos_fecha  ON prestamos (fecha_prestamo);

-- ---------------------------------------------------------------------
-- VISTA: ejemplares con su disponibilidad calculada
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_ejemplares AS
SELECT e.id_ejemplar, e.codigo_inventario, e.ubicacion, e.estado,
       l.id_libro, l.titulo, l.isbn,
       CASE
         WHEN e.estado <> 'Disponible' THEN e.estado
         WHEN EXISTS (SELECT 1 FROM prestamos p
                      WHERE p.id_ejemplar = e.id_ejemplar AND p.fecha_devolucion IS NULL) THEN 'Prestado'
         ELSE 'Disponible'
       END COLLATE utf8mb4_unicode_ci AS disponibilidad
FROM ejemplares e
JOIN libros l ON l.id_libro = e.id_libro;

-- ---------------------------------------------------------------------
-- VISTA: préstamos con datos legibles, días de retraso y multa estimada
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_prestamos AS
SELECT p.id_prestamo, p.fecha_prestamo, p.fecha_limite, p.fecha_devolucion,
       p.multa, p.multa_pagada,
       s.id_socio, s.matricula, CONCAT(s.nombre, ' ', s.apellidos) AS socio, t.nombre AS tipo_socio,
       e.id_ejemplar, e.codigo_inventario, l.id_libro, l.titulo,
       CASE
         WHEN p.fecha_devolucion IS NOT NULL THEN 'Devuelto'
         WHEN CURDATE() > p.fecha_limite THEN 'Vencido'
         ELSE 'Activo'
       END COLLATE utf8mb4_unicode_ci AS estado,
       GREATEST(DATEDIFF(COALESCE(DATE(p.fecha_devolucion), CURDATE()), p.fecha_limite), 0) AS dias_retraso,
       CASE
         WHEN p.fecha_devolucion IS NULL
           THEN GREATEST(DATEDIFF(CURDATE(), p.fecha_limite), 0) * t.multa_diaria
         ELSE p.multa
       END AS multa_calculada
FROM prestamos p
JOIN socios      s ON s.id_socio    = p.id_socio
JOIN tipos_socio t ON t.id_tipo     = s.id_tipo
JOIN ejemplares  e ON e.id_ejemplar = p.id_ejemplar
JOIN libros      l ON l.id_libro    = e.id_libro;
