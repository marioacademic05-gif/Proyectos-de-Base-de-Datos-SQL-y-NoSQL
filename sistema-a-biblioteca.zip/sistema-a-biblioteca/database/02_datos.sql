-- =====================================================================
--  SISTEMA A - BIBLIOTECA
--  Script 02: datos de ejemplo (fechas relativas a hoy)
-- =====================================================================
USE biblioteca;

INSERT INTO categorias (nombre) VALUES
('Bases de datos'), ('Programación'), ('Redes'), ('Matemáticas'),
('Literatura'), ('Historia'), ('Administración'), ('Física');

INSERT INTO autores (nombre, apellidos, nacionalidad) VALUES
('Ramez', 'Elmasri', 'Egipto'),             -- 1
('Shamkant', 'Navathe', 'India'),           -- 2
('Abraham', 'Silberschatz', 'Israel'),      -- 3
('Henry', 'Korth', 'Estados Unidos'),       -- 4
('Robert', 'Martin', 'Estados Unidos'),     -- 5
('Andrew', 'Tanenbaum', 'Estados Unidos'),  -- 6
('James', 'Kurose', 'Estados Unidos'),      -- 7
('Keith', 'Ross', 'Estados Unidos'),        -- 8
('James', 'Stewart', 'Canadá'),             -- 9
('Gabriel', 'García Márquez', 'Colombia'),  -- 10
('Juan', 'Rulfo', 'México'),                -- 11
('Octavio', 'Paz', 'México'),               -- 12
('Miguel', 'León-Portilla', 'México'),      -- 13
('Peter', 'Drucker', 'Austria'),            -- 14
('Raymond', 'Serway', 'Estados Unidos'),    -- 15
('Kristina', 'Chodorow', 'Estados Unidos'); -- 16

INSERT INTO libros (isbn, titulo, id_categoria, editorial, anio_publicacion) VALUES
('978-0133970777', 'Fundamentos de sistemas de bases de datos', 1, 'Pearson', 2016),           -- 1
('978-0078022159', 'Fundamentos de bases de datos', 1, 'McGraw-Hill', 2019),                  -- 2
('978-1491954461', 'MongoDB: la guía definitiva', 1, 'O''Reilly', 2019),                       -- 3
('978-0132350884', 'Código limpio', 2, 'Prentice Hall', 2008),                                 -- 4
('978-0134494166', 'Arquitectura limpia', 2, 'Prentice Hall', 2017),                           -- 5
('978-0133594140', 'Redes de computadoras', 3, 'Pearson', 2021),                               -- 6
('978-0133591385', 'Redes de computadoras: un enfoque descendente', 3, 'Pearson', 2017),       -- 7
('978-1285741550', 'Cálculo de una variable', 4, 'Cengage', 2015),                             -- 8
('978-1285740621', 'Cálculo de varias variables', 4, 'Cengage', 2015),                         -- 9
('978-0307474728', 'Cien años de soledad', 5, 'Vintage Español', 1967),                        -- 10
('978-8437604183', 'Pedro Páramo', 5, 'Cátedra', 1955),                                        -- 11
('978-9681604070', 'El laberinto de la soledad', 5, 'FCE', 1950),                              -- 12
('978-9683606058', 'Visión de los vencidos', 6, 'UNAM', 1959),                                 -- 13
('978-0060878979', 'La gerencia efectiva', 7, 'Harper', 1967),                                 -- 14
('978-1133947271', 'Física para ciencias e ingeniería', 8, 'Cengage', 2014),                   -- 15
('978-0136006633', 'Sistemas operativos modernos', 2, 'Pearson', 2014),                        -- 16
('978-8466356351', 'El amor en los tiempos del cólera', 5, 'Debolsillo', 1985),                -- 17
('978-6071503398', 'Administración: una perspectiva global', 7, 'McGraw-Hill', 2012);         -- 18

INSERT INTO libro_autor (id_libro, id_autor) VALUES
(1,1),(1,2),(2,3),(2,4),(3,16),(4,5),(5,5),(6,6),(7,7),(7,8),(8,9),(9,9),
(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,6),(17,10),(18,14);

-- Ejemplares (copias físicas)
INSERT INTO ejemplares (id_libro, codigo_inventario, ubicacion, estado) VALUES
(1,'BD-0001','Estante A1','Disponible'),(1,'BD-0002','Estante A1','Disponible'),(1,'BD-0003','Estante A1','Disponible'), -- 1-3
(2,'BD-0004','Estante A1','Disponible'),(2,'BD-0005','Estante A1','Mantenimiento'),                                   -- 4-5
(3,'BD-0006','Estante A2','Disponible'),(3,'BD-0007','Estante A2','Disponible'),                                       -- 6-7
(4,'PR-0001','Estante B1','Disponible'),(4,'PR-0002','Estante B1','Disponible'),                                       -- 8-9
(5,'PR-0003','Estante B1','Disponible'),                                                                               -- 10
(6,'RE-0001','Estante C1','Disponible'),(6,'RE-0002','Estante C1','Disponible'),                                       -- 11-12
(7,'RE-0003','Estante C1','Disponible'),                                                                               -- 13
(8,'MA-0001','Estante D1','Disponible'),(8,'MA-0002','Estante D1','Disponible'),(8,'MA-0003','Estante D1','Disponible'), -- 14-16
(9,'MA-0004','Estante D1','Disponible'),                                                                               -- 17
(10,'LI-0001','Estante E1','Disponible'),(10,'LI-0002','Estante E1','Disponible'),                                     -- 18-19
(11,'LI-0003','Estante E1','Disponible'),(12,'LI-0004','Estante E1','Disponible'),                                     -- 20-21
(13,'HI-0001','Estante F1','Disponible'),(14,'AD-0001','Estante G1','Disponible'),                                     -- 22-23
(15,'FI-0001','Estante H1','Disponible'),(15,'FI-0002','Estante H1','Baja'),                                           -- 24-25
(16,'PR-0004','Estante B2','Disponible'),(17,'LI-0005','Estante E2','Disponible'),(18,'AD-0002','Estante G1','Disponible'); -- 26-28

INSERT INTO tipos_socio (nombre, max_prestamos, dias_prestamo, multa_diaria) VALUES
('Alumno', 3, 7, 5.00),
('Docente', 5, 14, 3.00),
('Externo', 1, 3, 10.00);

INSERT INTO socios (matricula, nombre, apellidos, email, telefono, id_tipo) VALUES
('A2023001', 'Mariana', 'Torres Vega', 'mariana.torres@escuela.edu.mx', '6141112233', 1),   -- 1
('A2023002', 'Diego', 'Hernández Ruiz', 'diego.hernandez@escuela.edu.mx', '6142223344', 1), -- 2
('A2023003', 'Valeria', 'Gómez Soto', 'valeria.gomez@escuela.edu.mx', NULL, 1),             -- 3
('A2023004', 'Luis', 'Ramírez Cruz', 'luis.ramirez@escuela.edu.mx', '6144445566', 1),       -- 4
('A2023005', 'Fernanda', 'Ortiz Luna', 'fernanda.ortiz@escuela.edu.mx', NULL, 1),           -- 5
('A2023006', 'Jorge', 'Medina Paz', 'jorge.medina@escuela.edu.mx', '6146667788', 1),        -- 6
('D1001', 'Patricia', 'Salinas Mora', 'psalinas@escuela.edu.mx', '6147778899', 2),          -- 7
('D1002', 'Roberto', 'Aguilar Núñez', 'raguilar@escuela.edu.mx', NULL, 2),                  -- 8
('D1003', 'Claudia', 'Rivas Peña', 'crivas@escuela.edu.mx', '6149990011', 2),               -- 9
('E0001', 'Andrés', 'Vázquez León', 'andres.vazquez@correo.com', '6141010101', 3),          -- 10
('A2024007', 'Sofía', 'Castillo Lara', 'sofia.castillo@escuela.edu.mx', NULL, 1),           -- 11
('A2024008', 'Emiliano', 'Flores Díaz', 'emiliano.flores@escuela.edu.mx', '6141212121', 1); -- 12

-- Préstamos devueltos (historial). Algunos con retraso y multa.
INSERT INTO prestamos (id_ejemplar, id_socio, fecha_prestamo, fecha_limite, fecha_devolucion, multa, multa_pagada) VALUES
(1, 1,  NOW() - INTERVAL 90 DAY, CURDATE() - INTERVAL 83 DAY, NOW() - INTERVAL 85 DAY, 0, 0),
(8, 2,  NOW() - INTERVAL 80 DAY, CURDATE() - INTERVAL 73 DAY, NOW() - INTERVAL 70 DAY, 15.00, 1),
(18, 3, NOW() - INTERVAL 75 DAY, CURDATE() - INTERVAL 68 DAY, NOW() - INTERVAL 69 DAY, 0, 0),
(11, 7, NOW() - INTERVAL 70 DAY, CURDATE() - INTERVAL 56 DAY, NOW() - INTERVAL 60 DAY, 0, 0),
(14, 4, NOW() - INTERVAL 65 DAY, CURDATE() - INTERVAL 58 DAY, NOW() - INTERVAL 50 DAY, 40.00, 1),
(2, 5,  NOW() - INTERVAL 60 DAY, CURDATE() - INTERVAL 53 DAY, NOW() - INTERVAL 54 DAY, 0, 0),
(6, 8,  NOW() - INTERVAL 58 DAY, CURDATE() - INTERVAL 44 DAY, NOW() - INTERVAL 45 DAY, 0, 0),
(20, 1, NOW() - INTERVAL 55 DAY, CURDATE() - INTERVAL 48 DAY, NOW() - INTERVAL 49 DAY, 0, 0),
(1, 6,  NOW() - INTERVAL 50 DAY, CURDATE() - INTERVAL 43 DAY, NOW() - INTERVAL 38 DAY, 25.00, 0),
(9, 2,  NOW() - INTERVAL 45 DAY, CURDATE() - INTERVAL 38 DAY, NOW() - INTERVAL 39 DAY, 0, 0),
(21, 9, NOW() - INTERVAL 44 DAY, CURDATE() - INTERVAL 30 DAY, NOW() - INTERVAL 31 DAY, 0, 0),
(12, 3, NOW() - INTERVAL 40 DAY, CURDATE() - INTERVAL 33 DAY, NOW() - INTERVAL 34 DAY, 0, 0),
(15, 11,NOW() - INTERVAL 35 DAY, CURDATE() - INTERVAL 28 DAY, NOW() - INTERVAL 29 DAY, 0, 0),
(3, 7,  NOW() - INTERVAL 33 DAY, CURDATE() - INTERVAL 19 DAY, NOW() - INTERVAL 20 DAY, 0, 0),
(19, 12,NOW() - INTERVAL 30 DAY, CURDATE() - INTERVAL 23 DAY, NOW() - INTERVAL 20 DAY, 15.00, 0),
(10, 8, NOW() - INTERVAL 28 DAY, CURDATE() - INTERVAL 14 DAY, NOW() - INTERVAL 15 DAY, 0, 0),
(22, 10,NOW() - INTERVAL 25 DAY, CURDATE() - INTERVAL 22 DAY, NOW() - INTERVAL 18 DAY, 40.00, 1),
(4, 4,  NOW() - INTERVAL 22 DAY, CURDATE() - INTERVAL 15 DAY, NOW() - INTERVAL 16 DAY, 0, 0),
(8, 5,  NOW() - INTERVAL 20 DAY, CURDATE() - INTERVAL 13 DAY, NOW() - INTERVAL 14 DAY, 0, 0),
(13, 9, NOW() - INTERVAL 18 DAY, CURDATE() - INTERVAL 4 DAY,  NOW() - INTERVAL 5 DAY, 0, 0),
(26, 7, NOW() - INTERVAL 16 DAY, CURDATE() - INTERVAL 2 DAY,  NOW() - INTERVAL 3 DAY, 0, 0),
(24, 1, NOW() - INTERVAL 15 DAY, CURDATE() - INTERVAL 8 DAY,  NOW() - INTERVAL 9 DAY, 0, 0);

-- Préstamos abiertos: algunos vencidos y otros vigentes
INSERT INTO prestamos (id_ejemplar, id_socio, fecha_prestamo, fecha_limite) VALUES
(1, 2,  NOW() - INTERVAL 12 DAY, CURDATE() - INTERVAL 5 DAY),   -- vencido
(14, 6, NOW() - INTERVAL 10 DAY, CURDATE() - INTERVAL 3 DAY),   -- vencido
(18, 4, NOW() - INTERVAL 9 DAY,  CURDATE() - INTERVAL 2 DAY),   -- vencido
(6, 7,  NOW() - INTERVAL 6 DAY,  CURDATE() + INTERVAL 8 DAY),
(8, 1,  NOW() - INTERVAL 4 DAY,  CURDATE() + INTERVAL 3 DAY),
(11, 3, NOW() - INTERVAL 3 DAY,  CURDATE() + INTERVAL 4 DAY),
(20, 11,NOW() - INTERVAL 2 DAY,  CURDATE() + INTERVAL 5 DAY),
(2, 8,  NOW() - INTERVAL 1 DAY,  CURDATE() + INTERVAL 13 DAY),
(23, 9, NOW() - INTERVAL 1 DAY,  CURDATE() + INTERVAL 13 DAY),
(27, 12,NOW() - INTERVAL 5 HOUR, CURDATE() + INTERVAL 7 DAY);
